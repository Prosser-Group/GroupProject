﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Space_Crash
{
    public static class EnemySpawnStyles
    {

        private static Bitmap bmpSpecialEnemy2 = Properties.Resources.Enemy_Special_Ship_2;
        private static Bitmap bmpSpecialEnemy1 = Properties.Resources.EnemySpecial1;
        private static Bitmap bmpSpecialShock = Properties.Resources.ShockEnemy;
        private static Bitmap bmpEnemy = Properties.Resources.Enemy;

        private static Image SpecialEnemy2;
        private static Image Enemy;
        private static Image SpecialEnemy1;
        private static Image Shock;
        //base Line Enemy
        public static void SpawnEnemy(int I, Form1 ActiveForm)
        {
            int Counter = 0;
            while (Counter <= I)
            {
                ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
                ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "N");
                ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20) * Counter) - 24;
                ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
                ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

                    bmpEnemy.MakeTransparent(Color.Black);
                    Enemy = bmpEnemy;

                ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Image = Enemy;
                ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.BackColor = Color.Transparent;
                Counter += 1;
                ActiveForm.CurrentEnemy += 1;
                if (ActiveForm.CurrentEnemy == 254)
                {
                    ActiveForm.CurrentEnemy = 0;
                }
            }
        }

        //Light Enemy
        public static void SpawnEnemies(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "C");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20)) - 24;
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

                bmpSpecialEnemy1.MakeTransparent(Color.Black);
                SpecialEnemy1 = bmpSpecialEnemy1;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Image = SpecialEnemy1;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.BackColor = Color.Transparent;
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        //Crack Enemy
        public static void SpawnEnemies2(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "K");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width /= 2;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20)) - 24;
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

                bmpSpecialEnemy2.MakeTransparent(Color.Black);
                SpecialEnemy2 = bmpSpecialEnemy2;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Image = SpecialEnemy2;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.BackColor = Color.Transparent;
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        //Shock Enemy
        public static void SpawnRandomSideSpecal3(Form1 ActiveForm)
        {
            switch (ActiveForm.Special3)
            {
                case true:
                    SpawnEnemiesSpecal3(ActiveForm);
                    break;
                case false:
                    SpawnEnemiesSpecal31(ActiveForm);
                    break;
            }
        }

        public static void SpawnEnemiesSpecal3(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "S1");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width /= 2;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20)) - 24;
            ActiveForm.Special3 = false;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Movement = false;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;


            bmpSpecialShock.MakeTransparent(Color.Black);
                Shock = bmpSpecialShock;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Image = Shock;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.BackColor = Color.Transparent;
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        public static void SpawnEnemiesSpecal31(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "S2");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width /= 2;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (0 + ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width);
            ActiveForm.Special3 = true;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Movement = false;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;


            bmpSpecialShock.MakeTransparent(Color.Black);
                Shock = bmpSpecialShock;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Image = Shock;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.BackColor = Color.Transparent;

            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        public static void SpawnBoss1(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Bosses();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "A");
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

    }
}
