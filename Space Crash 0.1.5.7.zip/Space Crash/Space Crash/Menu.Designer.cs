﻿namespace Space_Crash
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picClose = new System.Windows.Forms.PictureBox();
            this.picCredits = new System.Windows.Forms.PictureBox();
            this.picSettings = new System.Windows.Forms.PictureBox();
            this.picStart = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCredits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSettings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStart)).BeginInit();
            this.SuspendLayout();
            // 
            // picClose
            // 
            this.picClose.BackColor = System.Drawing.Color.CornflowerBlue;
            this.picClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClose.Image = global::Space_Crash.Properties.Resources.Exit;
            this.picClose.Location = new System.Drawing.Point(217, 180);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(100, 50);
            this.picClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picClose.TabIndex = 3;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // picCredits
            // 
            this.picCredits.BackColor = System.Drawing.SystemColors.ControlText;
            this.picCredits.Image = global::Space_Crash.Properties.Resources.Credits;
            this.picCredits.Location = new System.Drawing.Point(217, 124);
            this.picCredits.Name = "picCredits";
            this.picCredits.Size = new System.Drawing.Size(100, 50);
            this.picCredits.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCredits.TabIndex = 2;
            this.picCredits.TabStop = false;
            this.picCredits.Click += new System.EventHandler(this.picCredits_Click);
            // 
            // picSettings
            // 
            this.picSettings.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.picSettings.Image = global::Space_Crash.Properties.Resources.Options;
            this.picSettings.Location = new System.Drawing.Point(217, 68);
            this.picSettings.Name = "picSettings";
            this.picSettings.Size = new System.Drawing.Size(100, 50);
            this.picSettings.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSettings.TabIndex = 1;
            this.picSettings.TabStop = false;
            this.picSettings.Click += new System.EventHandler(this.picSettings_Click);
            // 
            // picStart
            // 
            this.picStart.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picStart.Image = global::Space_Crash.Properties.Resources.Start;
            this.picStart.Location = new System.Drawing.Point(217, 12);
            this.picStart.Name = "picStart";
            this.picStart.Size = new System.Drawing.Size(100, 50);
            this.picStart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picStart.TabIndex = 0;
            this.picStart.TabStop = false;
            this.picStart.Click += new System.EventHandler(this.picStart_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 386);
            this.Controls.Add(this.picClose);
            this.Controls.Add(this.picCredits);
            this.Controls.Add(this.picSettings);
            this.Controls.Add(this.picStart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCredits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSettings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picStart;
        private System.Windows.Forms.PictureBox picSettings;
        private System.Windows.Forms.PictureBox picCredits;
        private System.Windows.Forms.PictureBox picClose;
    }
}