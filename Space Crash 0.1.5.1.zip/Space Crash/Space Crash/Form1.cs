﻿using System;
using System.Windows.Forms;
using System.Threading;
using System.Drawing;
using System.IO;
using WMPLib;

namespace Space_Crash
{
    public partial class Form1 : Form
    {
        public Player[] PlayerArray = new Player[0];
        public Bulet[] Shots = new Bulet[255];
        public PowerUps[] PlayerPowerUps = new PowerUps[255];
        public int CurrentPowerUp = 0;

        public Enemy[] Enemies = new Enemy[255];
        public int CurrentEnemy = 0;
        public int EnemyMoveCounter = 0;
        public int MovementCounter = 0;
        public int EnemyLineMove = 0;
        public int EnemyClock = 0;

        public bool TopMove = false;
        public bool leftMove = false;
        public bool RightMove = false;
        public bool DownMove = false;

        public int CurrentShot = 0; 
        public int PlayerID;
        public bool Special1 = false;
        public bool Special2 = false;

        public Random Rand = new Random();
        public string Enemy = "";
        public int PowerUpMovementCounter = 0;

        public bool CheatSpawn = false;
        public byte EnemyShotCounter = 0;

        public bool Special3 = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SpawnPlayers(1);
            PlayerID = 0;
            FitScreen();
        }

        public void FitScreen()
        {
            Width = UserInputs.SelectedScreen.Bounds.Width;
            Height = UserInputs.SelectedScreen.Bounds.Height;
            Left = 0;
            Top = 0;

            pnlUI.Height = Height / 8;
            pnlUI.Top = Height - pnlUI.Height;
            pnlUI.Width = Width;
            pnlUI.Left = 0;

            label1.Text = PlayerArray[PlayerID].Score.ToString();
            label2.Text = "Score";

            label3.Text = PlayerArray[PlayerID].Kills.ToString();
            label4.Text = "Kills";

            label1.Width = 80;
            label2.Width = label1.Width;
            label3.Width = label1.Width;
            label4.Width = label1.Width;

            label2.Top = pnlUI.Height / 8;
            label1.Top = label2.Top + label1.Height;

            label1.Left = label2.Left;

            label4.Top = label2.Top;
            label3.Top = label1.Top;

            label4.Left = label2.Left + label2.Width + 2;
            label3.Left = label4.Left;

            lblHealth.Text = "Charge";
            lblHealth.AutoSize = false;
            lblHealth.TextAlign = ContentAlignment.MiddleCenter;
            lblHealth.Top = label2.Top;
            lblHealth.Width = label2.Width;
            lblHealth.Left = (pnlUI.Width/2) - (lblHealth.Width/2) ;

            prbHealth.Left = (pnlUI.Width / 2) - (prbHealth.Width / 2);
            prbHealth.Top = label3.Top;

            lblLife.Text = PlayerArray[PlayerID].HitPoints.ToString();

            label6.Size = lblHealth.Size;
            label6.Left = prbHealth.Left;
            label6.Top = prbHealth.Top + label6.Height + 2;

            pbrLife.Top = label6.Top + label6.Height + 2;
            pbrLife.Left = prbHealth.Left;            

        }

        private void UpdateScreen()
        {
            // this updates the score and how many kills a player has
            if (PlayerArray[PlayerID] != null)
            {
                label3.Text = PlayerArray[PlayerID].Kills.ToString();
                label1.Text = PlayerArray[PlayerID].Score.ToString();
            }
            }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = true;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = true;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = true;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = true;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = true;
            }

            if (UserInputs.KeyMenu == e.KeyCode)
            {
                Thread frm = new Thread(new ThreadStart(Program.StartMenuThread));
                frm.Start();
                Close();
            }

            if (UserInputs.PreventSpawn == e.KeyCode && UserInputs.DevMode == true)
            {
                switch (CheatSpawn)
                {
                    case true:
                        CheatSpawn = false;
                        break;
                    case false:
                        CheatSpawn = true;
                        break;
                }
            }

            if (UserInputs.SpawnEnemyLine == e.KeyCode && UserInputs.DevMode == true)
            {
                SpawnEnemy(18);
            }
            if (UserInputs.SpawnEnemyLight == e.KeyCode && Special1 != true && UserInputs.DevMode == true)
            {
                SpawnEnemies();
                Special1 = true;
            }
            if (UserInputs.SpawnEnemyCracked == e.KeyCode && Special2 != true && UserInputs.DevMode == true)
            {
                SpawnEnemies2();
                Special2 = true;
            }
            if (Keys.D4 == e.KeyCode && UserInputs.DevMode == true)
            {
                int temp = Rand.Next(3);
                switch (temp)
                {
                    case 0:
                        PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                        PlayerPowerUps[CurrentPowerUp].CreateBlank("A", Width, Height);
                        CurrentPowerUp += 1;
                        Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                        break;

                    case 1:
                        PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                        PlayerPowerUps[CurrentPowerUp].CreateBlank("B", Width, Height);
                        CurrentPowerUp += 1;
                        Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                        break;

                    case 2:
                        PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                        PlayerPowerUps[CurrentPowerUp].CreateBlank("C", Width, Height);
                        CurrentPowerUp += 1;
                        Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                        break;
                    case 3:
                        PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                        PlayerPowerUps[CurrentPowerUp].CreateBlank("D", Width, Height);
                        CurrentPowerUp += 1;
                        Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                        break;
                }
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = false;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = false;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = false;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = false;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = false;
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            PlayingArea();
            //
            //Player Movement
            //
            if (PlayerArray[PlayerID] != null)
            {
                if (UserInputs.MoveDown == true && DownMove == false)
                {
                    PlayerArray[PlayerID].Body.Top += 3;
                }
                if (UserInputs.MoveLeft == true && leftMove == false)
                {
                    PlayerArray[PlayerID].Body.Left -= 3;
                }
                if (UserInputs.MoveRight == true && RightMove == false)
                {
                    PlayerArray[PlayerID].Body.Left += 3;
                }
                if (UserInputs.MoveUp == true && TopMove == false)
                {
                    PlayerArray[PlayerID].Body.Top -= 3;
                }
            }

            //
            //Player Shooting
            //
            if (UserInputs.FireShot == true && PlayerArray[PlayerID].ShotCoolDown >= 10)
            {
                if (CurrentShot == 254)
                {
                    CurrentShot = 0;
                }
                switch (PlayerArray[PlayerID].CurrentPowerUp)
                {
                    case "A":
                        CurrentShot += 1;
                        Shots[CurrentShot] = new Bulet();
                        Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                        Controls.Add(Shots[CurrentShot].Shot);
                        Shots[CurrentShot].PlayerID = PlayerID;

                        if (CurrentShot == 254)
                        {
                            CurrentShot = 0;
                        }
                        CurrentShot += 1;
                        Shots[CurrentShot] = new Bulet();
                        Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                        Controls.Add(Shots[CurrentShot].Shot);
                        Shots[CurrentShot].PlayerID = PlayerID;
                        Shots[CurrentShot].Shot.Left += (PlayerArray[PlayerID].Body.Width / 2);

                        if (CurrentShot == 254)
                        {
                            CurrentShot = 0;
                        }
                        CurrentShot += 1;
                        Shots[CurrentShot] = new Bulet();
                        Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                        Controls.Add(Shots[CurrentShot].Shot);
                        Shots[CurrentShot].PlayerID = PlayerID;
                        Shots[CurrentShot].Shot.Left -= (PlayerArray[PlayerID].Body.Width / 2);

                        PlayerArray[PlayerID].ShotCoolDown = 0;
                        break;

                    case "B":
                        CurrentShot += 1;
                        Shots[CurrentShot] = new Bulet();
                        Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                        Controls.Add(Shots[CurrentShot].Shot);
                        Shots[CurrentShot].PlayerID = PlayerID;
                        Shots[CurrentShot].Shot.Width /= 2;
                        Shots[CurrentShot].Shot.Height /= 2;
                        Shots[CurrentShot].Shot.Left = (PlayerArray[PlayerID].Body.Width / 2) + (PlayerArray[PlayerID].Body.Left) - (Shots[CurrentShot].Shot.Width / 2);
                        Shots[CurrentShot].Shot.Top = (PlayerArray[PlayerID].Body.Top + Shots[CurrentShot].Shot.Height);
                        PlayerArray[PlayerID].ShotCoolDown = 0;
                        break;

                    default:
                        CurrentShot += 1;
                        Shots[CurrentShot] = new Bulet();
                        Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                        Controls.Add(Shots[CurrentShot].Shot);
                        Shots[CurrentShot].PlayerID = PlayerID;
                        PlayerArray[PlayerID].ShotCoolDown = 0;
                        break;
                        
                }
            }
            else if (PlayerArray[PlayerID] != null)
            {
                PlayerArray[PlayerID].ShotCoolDown += 1;
            }

            //
            //Enemy Spawning
            //

            if (EnemyClock <= 0 && CheatSpawn == false)
            {
                int Temp = Rand.Next(20);
                switch (Temp)
                {
                    case 1:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 2:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 3:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 4:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 5:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 6:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 7:
                        if (Special2 == false)
                        {
                            SpawnEnemies2();
                            EnemyClock = 10;
                            Special2 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 8:
                        if (Special2 == false)
                        {
                            SpawnEnemies2();
                            EnemyClock = 10;
                            Special2 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 9:
                        if (Special2 == false)
                        {
                            SpawnEnemies2();
                            EnemyClock = 10;
                            Special2 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 10:

                        SpawnEnemiesSpecal3();
                        EnemyClock = 10;
                        break;
                    case 11:

                            SpawnEnemiesSpecal3();
                            EnemyClock = 10;
                        break;

                    default:
                        SpawnEnemy(18);
                        EnemyClock = 300;
                        break;
                }
                label5.Text = Temp.ToString();
            }
            else
            {
                EnemyClock -= 1;
            }

            //
            // Shot hitting target
            //

            int counter = 0;
            do
            {

                if (Shots[counter] != null)
                {
                    switch (Shots[counter].Shotter) 
                    {
                        case "E":
                            Shots[counter].Shot.Top += 5;
                            if (Shots[counter].Shot.Top + Shots[counter].Shot.Height >= Height - pnlUI.Height)
                            {
                                Controls.Remove(Shots[counter].Shot);
                                Shots[counter] = null;
                            }
                            if (PlayerArray[PlayerID] != null)
                            {
                                try
                                {
                                    if (Shots[counter].Colider.FindCollison(Shots[counter].Shot, PlayerArray[PlayerID].Body))
                                    {
                                        PlayerArray[PlayerID].HitPoints -= 1;
                                        Controls.Remove(Shots[counter].Shot);
                                        Shots[counter] = null;
                                        if (PlayerArray[PlayerID].HitPoints == 0)
                                        {

                                            GameTimer.Stop();
                                            MessageBox.Show("Game Over");
                                            MessageBox.Show("You killed " + PlayerArray[PlayerID].Kills.ToString() + " Enemies and Obtained a score of " + PlayerArray[PlayerID].Score.ToString());
                                            Controls.Remove(PlayerArray[PlayerID].Body);
                                            PlayerArray[PlayerID] = null;
                                        }
                                    }
                                    else
                                    {

                                    }
                                }
                                catch
                                {

                                }
                            }                            
                            break;
                        case "P":
                            Shots[counter].Shot.Top -= 5;
                            if (Shots[counter].Shot.Top <= 0)
                            {
                                Controls.Remove(Shots[counter].Shot);
                                Shots[counter] = null;
                            }
                            int tempCounter = 0;
                            while (tempCounter <= 254)
                            {
                                if (Enemies[tempCounter] != null)
                                {
                                    if (Shots[counter] != null)
                                    {
                                        if (Enemies[tempCounter].CollisionTest.FindCollison(Enemies[tempCounter].Body, Shots[counter].Shot))
                                        {
                                            if (PlayerArray[PlayerID] != null)
                                            {
                                                switch (Enemies[tempCounter].EnemyType)
                                                {
                                                    case "N":
                                                        PlayerArray[Shots[counter].PlayerID].Score += 10;
                                                        int temp = Rand.Next(99);
                                                        switch (temp)
                                                        {
                                                            case 0:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 1:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("B", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 2:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("C", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                        }

                                                        break;
                                                    case "C":
                                                        PlayerArray[Shots[counter].PlayerID].Score += 50;
                                                        Special1 = false;
                                                        int temp1 = Rand.Next(99);
                                                        switch (temp1)
                                                        {
                                                            case 0:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 1:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("B", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 2:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("C", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 3:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                        }
                                                        break;
                                                    case "K":
                                                        PlayerArray[Shots[counter].PlayerID].Score += 100;
                                                        Special2 = false;
                                                        int temp2 = Rand.Next(99);
                                                        switch (temp2)
                                                        {
                                                            case 0:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 1:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("B", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 2:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("C", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 3:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 4:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("B", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 5:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                        }
                                                        break;
                                                    case "S":
                                                        PlayerArray[Shots[counter].PlayerID].Score += 250;
                                                        int temp3 = Rand.Next(99);
                                                        switch (temp3)
                                                        {
                                                            case 0:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 1:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("B", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 2:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("C", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 3:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 4:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("B", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                            case 5:
                                                                PlayerPowerUps[CurrentPowerUp] = new PowerUps();
                                                                PlayerPowerUps[CurrentPowerUp].SetSpecial("A", Width, Height, Enemies[tempCounter].Body);
                                                                CurrentPowerUp += 1;
                                                                Controls.Add(PlayerPowerUps[CurrentPowerUp - 1].Body);
                                                                break;
                                                        }
                                                        break;
                                                    default:
                                                        PlayerArray[Shots[counter].PlayerID].Score += 10;
                                                        break;
                                                }
                                            }
                                            PlayerArray[Shots[counter].PlayerID].Kills += 1;
                                            Controls.Remove(Enemies[tempCounter].Body);
                                            Controls.Remove(Shots[counter].Shot);
                                            Shots[counter] = null;
                                            Enemies[tempCounter] = null;
                                        }
                                        else
                                        {

                                        }
                                    }
                                }
                                tempCounter += 1;
                            }

                            break;
                        default:
                            break;
                    }
                }
                counter += 1;
            } while (counter < 255);
            counter = 0;

            //
            //Enemy Movement
            //
                do
                {

                    if (Enemies[counter] != null)
                    {
                        switch (Enemies[counter].EnemyType)
                        {
                            case "C":
                                if (MovementCounter == 0)
                                {
                                    switch (Enemies[counter].Movement)
                                    {
                                        case true:
                                            if (Enemies[counter].Body.Left <= Width - Enemies[counter].Body.Width)
                                            {
                                                Enemies[counter].Body.Left += 8;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = false;
                                                Enemies[counter].Body.Top += 15;
                                            }
                                            break;

                                        case false:
                                            if (Enemies[counter].Body.Left >= 0)
                                            {
                                                Enemies[counter].Body.Left -= 8;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = true;
                                                Enemies[counter].Body.Top += 15;
                                            }
                                            break;
                                    default:
                                        Enemies[counter].Movement = true;
                                        Enemies[counter].Body.Top += 15;
                                        break;
                                    }
                                    if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                    {
                                        Controls.Remove(Enemies[counter].Body);
                                        Enemies[counter] = null;
                                    }
                                }
                                else
                                {
                                    MovementCounter -= 1;
                                }
                                break;

                            case "K":
                                if (MovementCounter == 0)
                                {
                                    switch (Enemies[counter].Movement)
                                    {
                                        case true:
                                            if (Enemies[counter].Body.Left <= Width - Enemies[counter].Body.Width)
                                            {
                                                Enemies[counter].Body.Left += 9;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = false;
                                                Enemies[counter].Body.Top += 30;
                                            }
                                            break;

                                        case false:
                                            if (Enemies[counter].Body.Left >= 0)
                                            {
                                                Enemies[counter].Body.Left -= 9;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = true;
                                                Enemies[counter].Body.Top += 30;
                                            }
                                            break;


                                    default:
                                        Enemies[counter].Movement = true;
                                        Enemies[counter].Body.Top += 15;
                                        break;
                                }
                                    if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                    {
                                        Controls.Remove(Enemies[counter].Body);
                                        Enemies[counter] = null;
                                    }
                                }
                                break;

                        case "S":
                            if (MovementCounter == 0)
                            {
                                switch (Enemies[counter].Movement)
                                {
                                    case true:
                                        int temp = (Width - Enemies[counter].Body.Width);

                                        if (Enemies[counter].Body.Left >= temp || Enemies[counter].Body.Left <= (Width / 12))
                                        {
                                            Enemies[counter].Movement = false;
                                            Enemies[counter].Body.Left -= 5;
                                        }
                                        else
                                        {
                                            Enemies[counter].Body.Left += 5;
                                        }

                                        Enemies[counter].Body.Top += 5;
                                        break;

                                    case false:
                                        int temp2 = (Width - (Width / 12));

                                        if ((Enemies[counter].Body.Left <= temp2 && Enemies[counter].Body.Left > (Width / 12)) || Enemies[counter].Body.Left <= 0)
                                        {
                                            Enemies[counter].Movement = true;
                                            Enemies[counter].Body.Left += 5;
                                        }
                                        else
                                        {
                                            Enemies[counter].Body.Left -= 5;
                                        }

                                        Enemies[counter].Body.Top += 5;
                                        break;


                                    default:
                                        Enemies[counter].Movement = true;
                                        Enemies[counter].Body.Top += 5;
                                        break;
                                }
                                if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                {
                                    Controls.Remove(Enemies[counter].Body);
                                    Enemies[counter] = null;
                                }
                            }
                            break;

                        default:
                                if (EnemyLineMove == 8)
                                {
                                    Enemies[counter].Body.Top += 5;
                                    if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                    {
                                        Controls.Remove(Enemies[counter].Body);
                                        Enemies[counter] = null;
                                    }
                                }
                                break;
                        }
                    }
                    counter += 1;
                } while (counter < 255);


            if (EnemyLineMove == 8)
            {
                EnemyLineMove = 0;
            }
            else
            {
                EnemyLineMove += 1;
            }

            if (MovementCounter == 0)
            {
                MovementCounter = 2;
            }
            else
            {
                MovementCounter -= 1;
            }


            //
            // Player Power Ups
            //
            counter = 0;
            if (PowerUpMovementCounter <= 0)
            {
                while (counter < 255)
                {
                    if (PlayerPowerUps[counter] != null)
                    {
                        if (PlayerPowerUps[counter].Colider.FindCollison(PlayerPowerUps[counter].Body, PlayerArray[PlayerID].Body) && PlayerPowerUps[counter].Name != "C")
                        {
                            PlayerArray[PlayerID].CurrentPowerUp = PlayerPowerUps[counter].Name;
                            Controls.Remove(PlayerPowerUps[counter].Body);
                            PlayerPowerUps[counter] = null;
                            prbHealth.Maximum = 1000;
                            prbHealth.Value = 1000;
                            prbHealth.Step -= 1;
                        }
                        else if (PlayerPowerUps[counter].Body.Top + PlayerPowerUps[counter].Body.Height >= pnlUI.Top)
                        {
                            Controls.Remove(PlayerPowerUps[counter].Body);
                            PlayerPowerUps[counter] = null;
                        }
                        else if (PlayerPowerUps[counter].Colider.FindCollison(PlayerPowerUps[counter].Body, PlayerArray[PlayerID].Body) && PlayerPowerUps[counter].Name == "C")
                        {
                            PlayerArray[PlayerID].HitPoints += 1;
                            Controls.Remove(PlayerPowerUps[counter].Body);
                            PlayerPowerUps[counter] = null;
                        }
                        else
                        {
                            PlayerPowerUps[counter].Body.Top += 5;
                        }
                    }
                    counter += 1;
                }
                PowerUpMovementCounter = 3;
            }
            else
            {
                PowerUpMovementCounter -= 1;
            }

            if (PlayerArray[PlayerID] != null)
            {

                if (prbHealth.Value != 0)
                {
                    prbHealth.Value -= 1;
                }
                else if (prbHealth.Value == 0)
                {
                    PlayerArray[PlayerID].CurrentPowerUp = "";

                }
            }

            if (EnemyShotCounter == 0)
            {
                EnemiesFire();
                EnemyShotCounter = 50;
            }
            else
            {
                EnemyShotCounter -= 1;
            }

            UpdateScreen(); // Changes Score and Kills

        }

        public void SpawnPlayers(int I)
        {
            
            int counter = 0;
            Array.Resize<Player>(ref PlayerArray, I + 1);
            do
            {

                PlayerArray[counter] = new Player();
                PlayerArray[counter].CreatePlayer(Form.ActiveForm, "bob");
                Controls.Add(PlayerArray[PlayerID].Body);
                counter += 1;

            } while (counter == I);
            
        }

        //base Line Enemy
        private void SpawnEnemy(int I)
        {
            int Counter = 0;
            while(Counter <= I)
            {
                Enemies[CurrentEnemy] = new Enemy();
                Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "N");
                Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20) * Counter) - 24;
                Controls.Add(Enemies[CurrentEnemy].Body);
                Counter += 1;
                CurrentEnemy += 1;
                if (CurrentEnemy == 254)
                {
                    CurrentEnemy = 0;
                }
            }
        }

        //Light Enemy
        private void SpawnEnemies()
        {
            Enemies[CurrentEnemy] = new Enemy();
            Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "C");
            Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20)) - 24;
            Controls.Add(Enemies[CurrentEnemy].Body);
            CurrentEnemy += 1;
            if (CurrentEnemy == 254)
            {
                CurrentEnemy = 0;
            }
        }

        //Crack Enemy
        private void SpawnEnemies2()
        {
            Enemies[CurrentEnemy] = new Enemy();
            Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "K");
            Enemies[CurrentEnemy].Body.Width /= 2;
            Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20)) - 24;
            Controls.Add(Enemies[CurrentEnemy].Body);
            CurrentEnemy += 1;
            if (CurrentEnemy == 254)
            {
                CurrentEnemy = 0;
            }
        }

        //Shock Enemy
        private void SpawnEnemiesSpecal3()
        {
            Enemies[CurrentEnemy] = new Enemy();
            Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "S");
            Enemies[CurrentEnemy].Body.Width /= 2;
            switch (Special3)
            {
                case false:
                    Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20)) - 24;
                    Special3 = true;
                    Enemies[CurrentEnemy].Movement = false;
                    break;
                case true:
                    Enemies[CurrentEnemy].Body.Left = (0 + Enemies[CurrentEnemy].Body.Width);
                    Special3 = false;
                    Enemies[CurrentEnemy].Movement = true;
                    break;
            }

            Controls.Add(Enemies[CurrentEnemy].Body);
            CurrentEnemy += 1;
            if (CurrentEnemy == 254)
            {
                CurrentEnemy = 0;
            }
        }

        private void PlayingArea()
        {
            if (PlayerArray[PlayerID] != null)
            {
                if (PlayerArray[PlayerID].Body.Left <= 0)
                {
                    leftMove = true;
                }
                else
                {
                    leftMove = false;
                }

                if (PlayerArray[PlayerID].Body.Left + PlayerArray[PlayerID].Body.Width >= Width)
                {
                    RightMove = true;
                }
                else
                {
                    RightMove = false;
                }

                if (PlayerArray[PlayerID].Body.Top + PlayerArray[PlayerID].Body.Height >= pnlUI.Top)
                {
                    DownMove = true;
                }
                else
                {
                    DownMove = false;
                }

                if (PlayerArray[PlayerID].Body.Top <= Height - (pnlUI.Height + ((Height - pnlUI.Height) / 3)))
                {
                    TopMove = true;
                }
                else
                {
                    TopMove = false;
                }
            }

        }

        private void EnemiesFire()
        {
            int temp = 0;
            int Temporary = Rand.Next(29);
            int Counter = 0;
            int Temporaraly = 0;
            while (temp < 255)
            {
                if (Enemies[temp] != null)
                {

                    switch (Enemies[temp].EnemyType)
                    {
                        case "N":
                            Temporaraly = Rand.Next(Rand.Next(19));
                            if (temp == Temporaraly && Counter != Temporary)
                            {
                                if (CurrentShot == 254)
                                {
                                    CurrentShot = 0;
                                }
                                CurrentShot += 1;
                                Shots[CurrentShot] = new Bulet();
                                Shots[CurrentShot].CreateShot(Form.ActiveForm, "E", Enemies[temp].Body);
                                Shots[CurrentShot].PlayerID = 0;
                                Controls.Add(Shots[CurrentShot].Shot);
                                Counter += 1;
                            }
                            break;

                        case "C":
                            if (CurrentShot == 254)
                            {
                                CurrentShot = 0;
                            }
                            CurrentShot += 1;
                            Shots[CurrentShot] = new Bulet();
                            Shots[CurrentShot].CreateShot(Form.ActiveForm, "E", Enemies[temp].Body);
                            Shots[CurrentShot].PlayerID = 0;
                            Controls.Add(Shots[CurrentShot].Shot);
                            break;

                        case "K":
                            if (CurrentShot == 254)
                            {
                                CurrentShot = 0;
                            }
                            CurrentShot += 1;
                            Shots[CurrentShot] = new Bulet();
                            Shots[CurrentShot].CreateShot(Form.ActiveForm, "E", Enemies[temp].Body);
                            Shots[CurrentShot].PlayerID = 0;
                            Controls.Add(Shots[CurrentShot].Shot);
                            break;
                    }


                    
                }
                temp += 1;
            }
        }


    }
}
