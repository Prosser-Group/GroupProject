﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    public class PowerUps
    {
        public HitBox Colider;
        public string Name;
        public PictureBox Body;

        public void SetSpecial(string N,int X, int Y, PictureBox P)
        {
            Body = new PictureBox
            {
                Height = (X / 80),
                Width = (Y / 48) / 2,
                Left = P.Left + (P.Width /2),
                Top = P.Top + (P.Height/2),
                BackColor = SystemColors.ButtonShadow,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            Name = N;
            Colider = new HitBox();
            switch (N)
            {
                case "A":
                    Body.Image = Properties.Resources.Double;
                    break;
                case "B":
                    Body.Image = Properties.Resources.Small;
                    break;
                case "C":
                    Body.Image = Properties.Resources.Health;
                    break;
                case "D":
                    Body.Image = Properties.Resources.Shield;
                    break;
            }
        }

        public void CreateBlank(string N, int X, int Y)
        {
            Body = new PictureBox
            {
                Width = (X / 80),
                Height = (Y / 48) / 2,
                Left = (X /2) - (((X / 80) / 2) / 2),
                Top = 0,
                BackColor = SystemColors.ButtonShadow,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            Name = N;
            Colider = new HitBox();

            switch (N)
            {
                case "A":
                    Body.Image = Properties.Resources.Double;
                    break;
                case "B":
                    Body.Image = Properties.Resources.Small;
                    break;
                case "C":
                    Body.Image = Properties.Resources.Health;
                    break;
                case "D":
                    Body.Image = Properties.Resources.Shield;
                    break;
            }
        }
    }
}
