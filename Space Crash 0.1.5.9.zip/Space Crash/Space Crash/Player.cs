﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
   public class Player
    {
        public PictureBox Body;
        public HitBox ColisionTester;
        public string CurrentPowerUp;
        public double Score;
        public int Kills;
        public int HitPoints;
        public bool GodMode;
        public string Name;
        public byte ShotCoolDown;
        public byte ShotCurrentCoolDown;
        public Bitmap[] PlayerSheild;

        public void CreatePlayer(Form PlayingFeild, string N)
        {
            Name = N;
            SetUpBody(Screen.PrimaryScreen.Bounds.Height, Screen.PrimaryScreen.Bounds.Width,PlayingFeild);
            Score = 0;
            Kills = 0;
            HitPoints = 3;
            ColisionTester = new HitBox();
            ShotCurrentCoolDown = 10;
            GodMode = false;
            PlayerSheild = new Bitmap[5];
            PlayerSheild[0] = Properties.Resources.PlayerShield1;
            PlayerSheild[1] = Properties.Resources.PlayerShield2;
            PlayerSheild[2] = Properties.Resources.PlayerShield3;
            PlayerSheild[3] = Properties.Resources.PlayerShield4;
            PlayerSheild[4] = Properties.Resources.PlayerShield5;
        }

        private void SetUpBody(int H, int W, Form PlayingFeild)
        {
            Body = new PictureBox
            {
                Width = W / 24,
                Height = H / 26,
                Top = H - ((H / 18) + (H / 8)),
                Left = (W / 2) - (W / 20),
                BackColor = Color.Transparent,
                Parent = PlayingFeild
            };
            
        }

    }
}
