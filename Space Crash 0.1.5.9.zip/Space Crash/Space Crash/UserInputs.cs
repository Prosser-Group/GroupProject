﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Space_Crash
{
    public static class UserInputs
    {
        public static Keys KeyUp = Keys.Up;
        public static bool MoveUp = false;
        public static Keys KeyRight = Keys.Right;
        public static bool MoveRight = false;
        public static Keys KeyDown = Keys.Down;
        public static bool MoveDown = false;
        public static Keys KeyLeft = Keys.Left;
        public static bool MoveLeft = false;

        public static Keys KeyShot = Keys.Space;
        public static bool FireShot = false;
        public static Keys KeyMenu = Keys.Escape;

        public static Screen SelectedScreen = Screen.PrimaryScreen;

        public static bool DevMode = false;

        public static Keys PreventSpawn = Keys.F;
        public static Keys GodMode = Keys.G;
        public static Keys ClearWorld = Keys.H;
        public static Keys SpawnEnemyLine = Keys.D1;
        public static Keys SpawnEnemyLight = Keys.D2;
        public static Keys SpawnEnemyCracked = Keys.D3;
        public static Keys SpawnPowerUp = Keys.D4;

        public static void CreateSocreBord(Player P)
        {
            string path = Path.GetFullPath(Properties.Resources.Enemy_Shot1.ToString());
            path = path.Remove(path.Length - 21, 21);

            if (!File.Exists(path + "LeaderBoard"))
            {
                File.Create(path + "LeaderBoard");
            }


            FileStream FS = new FileStream(path + "LeaderBoard", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
            FileStream FSW = new FileStream(path + "LeaderBoard", FileMode.Open, FileAccess.Write, FileShare.ReadWrite);
            StreamWriter Writer;
            Player[] PlayerArray;

            StreamReader reader = new StreamReader(FS, Encoding.Default);

            try
            {
                reader = new StreamReader(FS, Encoding.Default);
                string Temp;
                Temp = reader.ReadLine();
                if (Temp != null)
                {
                    int Temp2 = int.Parse(Temp);
                    PlayerArray = new Player[Temp2 + 1];
                    PlayerArray[Temp2] = P;
                    int counter = 0;
                    try
                    {
                        while (counter < Temp2)
                        {
                            PlayerArray[counter] = new Player
                            {
                                Name = reader.ReadLine(),
                                Score = double.Parse(reader.ReadLine()),
                                Kills = int.Parse(reader.ReadLine())
                        };
                            counter += 1;
                        }
                    }
                    catch
                    {

                    }
                    reader.Close();

                    Writer = new StreamWriter(FSW, Encoding.Default);
                    Writer.WriteLine(Temp2 + 1);
                    counter = 0;
                    while (counter <= Temp2)
                    {
                        Writer.WriteLine(PlayerArray[counter].Name);
                        Writer.WriteLine(PlayerArray[counter].Score);
                        Writer.WriteLine(PlayerArray[counter].Kills);
                        counter += 1;
                    }
                    Writer.Close();

                }
                else
                {
                    reader.Close();
                    Writer = new StreamWriter(FSW, Encoding.Default);
                    Writer.WriteLine("1");
                    Writer.WriteLine(P.Name);
                    Writer.WriteLine(P.Score);
                    Writer.WriteLine(P.Kills);
                    Writer.Close();
                }

            }
            catch
            {
                reader.Close();
                Writer = new StreamWriter(FSW, Encoding.Default);
                Writer.WriteLine("1");
                Writer.WriteLine(P.Name);
                Writer.WriteLine(P.Score);
                Writer.WriteLine(P.Kills);
                Writer.Close();
            }

           
        }

        private static dynamic FindLargestPlayer(Player[] P)
        {
            Player Temp = new Player
            {
                Score = 0,
                Kills = 0,
                Name = ""
            };
            int counter = 0;
            try
            {
                while (counter <= P.Length)
                {
                    if (P[counter].Score > Temp.Score)
                    {
                        Temp = P[counter];
                    }
                    else if (P[counter].Score == Temp.Score && P[counter].Kills > Temp.Kills)
                    {
                        Temp = P[counter];
                    }                    
                    counter += 1;
                }
                counter = 0;
                while (counter <= P.Length)
                {
                    if (P[counter] == Temp)
                    {
                        P[counter] = null;
                    }
                    counter += 1;
                }
            }
            catch
            {

            }

            
            return Temp;

        }

        private static dynamic CreateNewArray(int size, Player[] P)
        {
            Player[] PlayerArry = new Player[size];
            int counter = 0;
            while (counter <= size - 1)
            {
                FindLargestPlayer(P);
                counter += 1;
            }
            Player[] temp = new Player[size + 1];
            counter = 0;
            while (counter <= size)
            {
                temp[counter] = PlayerArry[counter];
                counter += 1;
            }
            return temp;

        }

        public static dynamic ReadScoreBoard()
        {

            try
            {
                StreamReader reader;
                string path = Path.GetFullPath(Properties.Resources.Enemy_Shot1.ToString());
                path = path.Remove(path.Length - 21, 21);
                FileStream FS = new FileStream(path + "LeaderBoard", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
                reader = new StreamReader(FS,Encoding.Default);
                int counter = 0;
                int Temp2 = int.Parse(reader.ReadLine());
                Player[] PlayerArry = new Player[Temp2];
                while (counter < Temp2)
                {
                    PlayerArry[counter] = new Player
                    {
                        Name = reader.ReadLine(),
                        Score = double.Parse(reader.ReadLine()),
                        Kills = int.Parse(reader.ReadLine())
                    };
                    counter += 1;
                }
                return PlayerArry;
            }
            catch
            {
                return null;
            }
        }

        public static dynamic FindNumberOfPlayersOnScoreBoard()
        {
            StreamReader reader;
            string path = Path.GetFullPath(Properties.Resources.Enemy_Shot1.ToString());
            path = path.Remove(path.Length - 21, 21);
            FileStream FS = new FileStream(path + "LeaderBoard", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
            reader = new StreamReader(FS, Encoding.Default);
            int Temp = int.Parse(reader.ReadLine());

            return Temp;
        }

    }
}
