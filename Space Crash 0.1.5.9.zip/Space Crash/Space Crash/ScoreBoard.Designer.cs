﻿namespace Space_Crash
{
    partial class ScoreBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.vsbPageScroller = new System.Windows.Forms.VScrollBar();
            this.SuspendLayout();
            // 
            // vsbPageScroller
            // 
            this.vsbPageScroller.Location = new System.Drawing.Point(934, 48);
            this.vsbPageScroller.Name = "vsbPageScroller";
            this.vsbPageScroller.Size = new System.Drawing.Size(17, 80);
            this.vsbPageScroller.TabIndex = 0;
            this.vsbPageScroller.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbPageScroller_Scroll);
            // 
            // ScoreBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 618);
            this.Controls.Add(this.vsbPageScroller);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ScoreBoard";
            this.Text = "ScoreBoard";
            this.Load += new System.EventHandler(this.ScoreBoard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.VScrollBar vsbPageScroller;
    }
}