﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class ScoreBoard : Form
    {
        private PLayerScore[] DisplayPlayers;
        private Player[] playerArray;
        private int intNum;
        private int LastScroll;

        public ScoreBoard()
        {
            InitializeComponent();
        }

        private void ScoreBoard_Load(object sender, EventArgs e)
        {
            vsbPageScroller.Left = Width - 35;
            vsbPageScroller.Top = 0;
            vsbPageScroller.Height = Height - 35;
            int temp = UserInputs.FindNumberOfPlayersOnScoreBoard();
            playerArray = new Player[temp];
            playerArray = UserInputs.ReadScoreBoard();
            DisplayPlayers = new PLayerScore[temp];
            int counter = 0;
             while(counter < temp)
            {
                    DisplayPlayers[counter] = new PLayerScore
                    {
                        Name = playerArray[counter].Name,
                        Score = playerArray[counter].Score,
                        Kills = playerArray[counter].Kills

                    };               
                counter += 1;
            }
            intNum = temp;
            FindTopScore();
            LastScroll = vsbPageScroller.Value;
        }

        private void FindTopScore()
        {
            int counter = 0;
            int counter2 = 0;
            PLayerScore[] Temp = new PLayerScore[intNum];
            int[] saves = new int[intNum];
            bool Usable = true;

            while (counter < intNum)
            {
                while (counter2 < intNum)
                {
                    Usable = FindValues(counter2, saves);
                    if (Temp[counter] == null)
                    {
                        Temp[counter] = DisplayPlayers[counter2];
                        saves[counter] = counter2;
                    }
                    else if (Temp[counter].Score < DisplayPlayers[counter2].Score && Usable)
                    {
                        Temp[counter] = DisplayPlayers[counter2];
                        saves[counter] = counter2;
                    }
                    else if (Temp[counter].Score == DisplayPlayers[counter2].Score && DisplayPlayers[counter2].Kills > Temp[counter].Kills && Usable)
                    {
                        Temp[counter] = DisplayPlayers[counter2];
                        saves[counter] = counter2;
                    }

                    counter2 += 1;
                }
                counter2 = 0;
                counter += 1;
            }
            DisplayPlayers = Temp;
            DisplayScores();
        }

        private dynamic FindValues(int num, int[] Nums)
        {
            bool temp = true;
            int counter = 0;

            while (counter < intNum)
            {
                if (Nums[counter] == num)
                {
                    temp = false;
                    break;
                }
                counter += 1;
            }

            return temp;
        }

        private void DisplayScores()
        {
            int counter = 0;
            while (counter < intNum)
            {
                try
                {
                    Label temp;                
                        DisplayPlayers[counter].picPlayerRank = new PictureBox
                        {
                            Left = 0 + (Width / 12) / 2,
                            Top = ((((Width / 7) /2) + 10) * (counter +1)) - (((Width / 7) / 2)/2),
                            Width = (Width / 7) / 2,
                            Height = (Width / 7) / 2,
                            BackColor = Color.Black
                        };

                        Controls.Add(DisplayPlayers[counter].picPlayerRank);

                        temp = new Label
                        {
                            AutoSize = false,
                            Top = (((10 + (Width / 7) / 2) * (counter + 1)) - (23 / 2)),
                            Left = (0 + (Width / 12) / 2) + ((Width / 7) / 2) + ((Width / 12) / 2),
                            Text = DisplayPlayers[counter].Name
                        };
                        DisplayPlayers[counter].lblName = temp;
                        Controls.Add(DisplayPlayers[counter].lblName);

                        temp = new Label
                        {
                            AutoSize = false,
                            Top = (((10 + (Width / 7) / 2) * (counter + 1)) - (23 / 2)),
                            Left = ((0 + (Width / 12) / 2) + ((Width / 7) / 2) + ((Width / 12) / 2)) + 100 + ((Width / 12) / 2),
                            Text = DisplayPlayers[counter].Kills.ToString()
                        };

                        DisplayPlayers[counter].lblScore = temp;
                        Controls.Add(DisplayPlayers[counter].lblScore);

                        temp = new Label
                        {
                            AutoSize = false,
                            Top = (((10 + (Width / 7) / 2) * (counter + 1)) - (23 / 2)),
                            Left = (((0 + (Width / 12) / 2) + ((Width / 7) / 2) + ((Width / 12) / 2)) + 100 + ((Width / 12) / 2)) + 100 + ((Width / 12) / 2),
                            Text = DisplayPlayers[counter].Score.ToString()
                        };

                    DisplayPlayers[counter].Place = DisplayPlayers[counter].picPlayerRank.Top;
                    DisplayPlayers[counter].PlaceL = DisplayPlayers[counter].lblScore.Top;
                        DisplayPlayers[counter].lblKills = temp;
                        Controls.Add(DisplayPlayers[counter].lblKills);
                        vsbPageScroller.Maximum = (((10 + (Width / 7) / 2) * (counter + 1)) - (23 / 2));                    
                    counter += 1;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                    counter += 1;
                }
                }
        }

        private void vsbPageScroller_Scroll(object sender, ScrollEventArgs e)
        {
            int counter = 0;
            while (counter < intNum)
            {
                if (LastScroll < vsbPageScroller.Value)
                {
                    DisplayPlayers[counter].Scrolling(DisplayPlayers[counter].Place - vsbPageScroller.Value, true, DisplayPlayers[counter].PlaceL - vsbPageScroller.Value);
                }
                else if (LastScroll > vsbPageScroller.Value)
                {
                    DisplayPlayers[counter].Scrolling(DisplayPlayers[counter].Place - vsbPageScroller.Value, false, DisplayPlayers[counter].PlaceL - vsbPageScroller.Value);
                }
                counter += 1;
            }
            LastScroll = vsbPageScroller.Value;
        }
    }
}
