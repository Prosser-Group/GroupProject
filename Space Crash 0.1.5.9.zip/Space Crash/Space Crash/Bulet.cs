﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    public class Bulet
    {
        public PictureBox Shot;
        public string Shotter = "";
        public int PlayerID = 9999;
        public HitBox Colider;
        public Bitmap[] ShotDecay;
        public bool Death;
        public byte Deaths;

        public void CreateShot(Form PlayingFeild, string N, PictureBox P)
        {
            Shotter = N;
            Colider = new HitBox();
            SetUpShot(PlayingFeild.Height, PlayingFeild.Width,P, PlayingFeild);
            ShotDecay = new Bitmap[2];
            Deaths = 0;
            switch (N)
            {
                case "E":
                    ShotDecay[0] = Properties.Resources.Enemy_Shot1;
                    ShotDecay[1] = Properties.Resources.Enemy_Shot2;
                    break;
                default:
                    ShotDecay[0] = Properties.Resources.Player_Shot2;
                    ShotDecay[1] = Properties.Resources.Player_Shot2;
                    break;
            }
        }

        private void SetUpShot(int H, int W, PictureBox P, Form PlayingFeild)
        {
            Shot = new PictureBox
            {
                Width = (W / 80) / 2,
                Height = H / 40,
                Top = P.Top - H / 42,
                Left = P.Left + ((P.Width / 2) -((W / 120) / 2)),
                BackColor = Color.Transparent,
                Parent = PlayingFeild
            };

        }
    }


}
