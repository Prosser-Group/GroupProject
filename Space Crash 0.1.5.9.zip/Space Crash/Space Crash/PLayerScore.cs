﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    public class PLayerScore
    {
        public string Name;
        public int Kills;
        public double Score;

        public PictureBox picPlayerRank;
        public Label lblName;
        public Label lblKills;
        public Label lblScore;
    }
}
