﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    public class Status
    {
        public StatsList Player_Being;

        private int HitPoints;
        private int ManaPoints;

        private int HPMAX;
        private int MANAMAX;


    }
}
