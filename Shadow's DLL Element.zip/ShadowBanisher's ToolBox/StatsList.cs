﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    public class StatsList
    {
        public Stat[] Stats = new Stat[6];


        public void SetClass()
        {
            int DeafultLevel = 4;
            Stats[0].Name = "Strength";
            Stats[0].SetID = "0";
            Stats[0].AddLevels = DeafultLevel;

            Stats[1].Name = "Dextarity";
            Stats[1].SetID = "1";
            Stats[1].AddLevels = DeafultLevel;

            Stats[2].Name = "Constitution";
            Stats[2].SetID = "2";
            Stats[2].AddLevels = DeafultLevel;

            Stats[3].Name = "Intelegence";
            Stats[3].SetID = "3";
            Stats[3].AddLevels = DeafultLevel;

            Stats[4].Name = "Wisdom";
            Stats[4].SetID = "4";
            Stats[4].AddLevels = DeafultLevel;

            Stats[5].Name = "Charisma";
            Stats[5].SetID = "5";
            Stats[5].AddLevels = DeafultLevel;
        }

        public void ResetClass()
        {
            Stats = new Stat[6];
        }

        public void RedifineClass(int Re)
        {
            Stats = new Stat[Re];
        }
    }
}
