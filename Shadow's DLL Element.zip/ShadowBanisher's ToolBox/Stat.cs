﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    public class Stat
    {
        private string ID = "";
        public string Name = "";

        private int Level = 0;
        private double XP = 0;

        public double LevelCalculation
        {
            set
            {
                XP = value;
            }
        }

         public int DisplayLevel
        {
            get
            {
                return Level;
            }
        }

        public double DisplayXP
        {
            get
            {
                return XP;
            }
        }

        public int AddLevels
        {
            set
            {
                Level = value;
            }
        } 

        public int AddLevel
        {
            set
            {
                Level += 1;
            }
        }

        public string DisplayID
        {
            get
            {
                return ID;
            }
        }

        public string SetID
        {
            set
            {
                ID = value;
            }
        }


    }
}
