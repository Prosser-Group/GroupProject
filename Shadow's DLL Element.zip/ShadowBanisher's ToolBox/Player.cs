﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    /// <summary>
    /// Player element is an element that encompases the basic needs for a Playable object
    /// </summary>
    public class Player
    {
        public Vector_2 Body;
        public SightPoint Point_Of_Veiw;

        public Status Player_Condition;
    }
}
