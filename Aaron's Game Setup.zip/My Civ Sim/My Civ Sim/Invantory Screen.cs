﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Civ_Sim
{
    public partial class Invantory_Screen : Form
    {
        public Invantory_Screen()
        {
            InitializeComponent();
        }

        private void Invantory_Screen_Load(object sender, EventArgs e)
        {

        }

        private void Invantory_Screen_FormClosed(object sender, FormClosedEventArgs e)
        {
            BackGround.InvantoryScreenup = false;
        }
    }
}
