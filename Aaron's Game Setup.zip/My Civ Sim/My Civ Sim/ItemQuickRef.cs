﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_Civ_Sim
{
    class ItemQuickRef
    {
        public string Name;
        public int ID;
        public string Type;

        public int Ammount;
        private int MaxStack;

        public void stackMax(int Stacks)
        {
            MaxStack = Stacks;
        }

        public void Levelstacks(int HeldAmoount)
        {
            if (Ammount > MaxStack)
            {
                HeldAmoount = Ammount - MaxStack;
                Ammount = MaxStack;

            }
        }
        public void ResetItem()
        {
            if (Ammount <= 0)
            {
                MaxStack = 0;
                ID = 0;
                Type = "";
                Ammount = 0;
                Name = "";
            }
        }
    }
}
