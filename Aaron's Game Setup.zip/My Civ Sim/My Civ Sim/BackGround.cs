﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_Civ_Sim
{
    public class BackGround
    {
        public static string Version = "0.0.3";
        //This makes it so that the invantory can only be opnened once.
        public static bool InvantoryScreenup { get; set; }



        //This will hold all info on Items and what not


    }
}
