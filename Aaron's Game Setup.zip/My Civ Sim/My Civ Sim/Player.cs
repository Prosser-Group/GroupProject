﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Civ_Sim
{
    class Player
    {
        private PictureBox PlayerBody;

        public double PlayerX;
        public double PlayerY;

        public void CallBody(PictureBox P)
        {
            PlayerBody = P;
            PlayerX = P.Left;
            PlayerY = P.Top;
        }

        public void ScrollScreen(double ScrollLeft, double ScrollTop)
        {
            PlayerBody.Left = int.Parse((PlayerX - ScrollLeft).ToString());
            PlayerBody.Top = int.Parse((PlayerY - ScrollTop).ToString());
        }
    }
}
