﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace My_Civ_Sim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width;
            Height = Screen.PrimaryScreen.Bounds.Height;
            Left = 0;
            Top = 0;
            UI_Setup();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
        }

        private void UI_Setup()
        {
            Bitmap temp;
            picTopChart.Width = Width;
            picTopChart.Height = Height / 14;
            picTopChart.Top = 0;
            picTopChart.Left = 0;


            picSideChannal.Width = Width / 7;
            picSideChannal.Height = Height;
            picSideChannal.Left = 0;
            picSideChannal.Top = picTopChart.Height;
            temp = (Bitmap)Image.FromFile(@"H:\Visual Studio 2015\Projects\My Civ Sim\My Civ Sim\Resources\_SideBarbmp.bmp");
            temp.MakeTransparent(Color.White);
            picSideChannal.Image = temp;
            
        }
    }
}
