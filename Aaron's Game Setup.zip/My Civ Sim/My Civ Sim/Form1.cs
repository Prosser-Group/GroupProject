﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace My_Civ_Sim
{
    public partial class Form1 : Form
    {
        private Player Character = new Player();
        private double ScrollX;
        private double ScrollY;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width;
            Height = Screen.PrimaryScreen.Bounds.Height;
            Left = 0;
            Top = 0;
            UI_Setup();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
            else if (e.KeyCode == Keys.W)
            {
                Character.PlayerY -= 2;
                picCharacter.Top -= 2;
            }
            else if (e.KeyCode == Keys.D)
            {
                Character.PlayerX += 2;
                picCharacter.Left += 2;
            }
            else if (e.KeyCode == Keys.S)
            {
                Character.PlayerY += 2;
                picCharacter.Top += 2;
            }
            else if (e.KeyCode == Keys.A)
            {
                Character.PlayerX -= 2;
                picCharacter.Left -= 2;
            }
            else if (e.KeyCode == Keys.Up)
            {
                ScrollY -= 5;
            }
            else if (e.KeyCode == Keys.Right)
            {
                ScrollX += 5;
            }
            else if (e.KeyCode == Keys.Down)
            {
                ScrollY += 5;
            }
            else if (e.KeyCode == Keys.Left)
            {
                ScrollX -= 5;
            }
        }

        private void UI_Setup()
        {
            Bitmap temp;
            picTopChart.Width = Width;
            picTopChart.Height = Height / 14;
            picTopChart.Top = 0;
            picTopChart.Left = 0;
            temp = (Bitmap)Image.FromFile(@"C:\Users\Aaron Zirkle\Desktop\My Civ Sim\My Civ Sim\Resources\_UpperBarbmp.bmp");
            temp.MakeTransparent(Color.White);
            picTopChart.Image = temp;

            picSideChannal.Width = Width / 7;
            picSideChannal.Height = Height;
            picSideChannal.Left = 0;
            picSideChannal.Top = picTopChart.Height;
            temp = (Bitmap)Image.FromFile(@"C:\Users\Aaron Zirkle\Desktop\My Civ Sim\My Civ Sim\Resources\_SideBarbmp.bmp");
            temp.MakeTransparent(Color.White);
            picSideChannal.Image = temp;

            pnlPlayFeild.Left = picSideChannal.Width;
            pnlPlayFeild.Top = picTopChart.Height;
            pnlPlayFeild.Width = Width - picSideChannal.Width;
            pnlPlayFeild.Height = Height - picTopChart.Height;

            Character.CallBody(picCharacter);

            
        }


        private void ScrollTimer_Tick(object sender, EventArgs e)
        {
            if (Cursor.Position.X >= 0 && Cursor.Position.X <= 20)
            {
                ScrollX -= 1;
            }
            else if (Cursor.Position.X >= Width - 20 && Cursor.Position.X <= Width)
            {
                ScrollX += 1;
            }
            else if (Cursor.Position.Y >= 0 && Cursor.Position.Y <= 20)
            {
                ScrollY -= 1;
            }
            else if (Cursor.Position.Y >= Height - 20 && Cursor.Position.Y <= Height)
            {
                ScrollY += 1;
            }

            Character.ScrollScreen(ScrollX, ScrollY);
        }
    }
}
