﻿namespace My_Civ_Sim
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picSideChannal = new System.Windows.Forms.PictureBox();
            this.picTopChart = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSideChannal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTopChart)).BeginInit();
            this.SuspendLayout();
            // 
            // picSideChannal
            // 
            this.picSideChannal.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picSideChannal.Location = new System.Drawing.Point(0, 0);
            this.picSideChannal.Name = "picSideChannal";
            this.picSideChannal.Size = new System.Drawing.Size(100, 50);
            this.picSideChannal.TabIndex = 0;
            this.picSideChannal.TabStop = false;
            // 
            // picTopChart
            // 
            this.picTopChart.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.picTopChart.Location = new System.Drawing.Point(158, 104);
            this.picTopChart.Name = "picTopChart";
            this.picTopChart.Size = new System.Drawing.Size(100, 50);
            this.picTopChart.TabIndex = 1;
            this.picTopChart.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 405);
            this.Controls.Add(this.picTopChart);
            this.Controls.Add(this.picSideChannal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picSideChannal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTopChart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picSideChannal;
        private System.Windows.Forms.PictureBox picTopChart;
    }
}

