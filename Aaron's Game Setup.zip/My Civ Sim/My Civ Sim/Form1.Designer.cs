﻿namespace My_Civ_Sim
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picTopChart = new System.Windows.Forms.PictureBox();
            this.picSideChannal = new System.Windows.Forms.PictureBox();
            this.pnlPlayFeild = new System.Windows.Forms.Panel();
            this.picCharacter = new System.Windows.Forms.PictureBox();
            this.ScrollTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picTopChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSideChannal)).BeginInit();
            this.pnlPlayFeild.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCharacter)).BeginInit();
            this.SuspendLayout();
            // 
            // picTopChart
            // 
            this.picTopChart.BackColor = System.Drawing.Color.Black;
            this.picTopChart.Location = new System.Drawing.Point(158, 104);
            this.picTopChart.Name = "picTopChart";
            this.picTopChart.Size = new System.Drawing.Size(100, 50);
            this.picTopChart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTopChart.TabIndex = 1;
            this.picTopChart.TabStop = false;
            // 
            // picSideChannal
            // 
            this.picSideChannal.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picSideChannal.Location = new System.Drawing.Point(31, 208);
            this.picSideChannal.Name = "picSideChannal";
            this.picSideChannal.Size = new System.Drawing.Size(100, 50);
            this.picSideChannal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSideChannal.TabIndex = 0;
            this.picSideChannal.TabStop = false;
            // 
            // pnlPlayFeild
            // 
            this.pnlPlayFeild.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlPlayFeild.Controls.Add(this.picCharacter);
            this.pnlPlayFeild.Location = new System.Drawing.Point(166, 112);
            this.pnlPlayFeild.Name = "pnlPlayFeild";
            this.pnlPlayFeild.Size = new System.Drawing.Size(200, 100);
            this.pnlPlayFeild.TabIndex = 2;
            // 
            // picCharacter
            // 
            this.picCharacter.BackColor = System.Drawing.SystemColors.Control;
            this.picCharacter.Location = new System.Drawing.Point(64, 17);
            this.picCharacter.Name = "picCharacter";
            this.picCharacter.Size = new System.Drawing.Size(64, 64);
            this.picCharacter.TabIndex = 3;
            this.picCharacter.TabStop = false;
            // 
            // ScrollTimer
            // 
            this.ScrollTimer.Enabled = true;
            this.ScrollTimer.Interval = 10;
            this.ScrollTimer.Tick += new System.EventHandler(this.ScrollTimer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 405);
            this.Controls.Add(this.pnlPlayFeild);
            this.Controls.Add(this.picTopChart);
            this.Controls.Add(this.picSideChannal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picTopChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSideChannal)).EndInit();
            this.pnlPlayFeild.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCharacter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picSideChannal;
        private System.Windows.Forms.PictureBox picTopChart;
        private System.Windows.Forms.Panel pnlPlayFeild;
        private System.Windows.Forms.PictureBox picCharacter;
        private System.Windows.Forms.Timer ScrollTimer;
    }
}

