﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Crash
{
    public class Waves
    {
        new Random rand = new Random();

        public int WaveCounter = 0;

        public void StartWave(Form1 F)
        {
            switch (WaveCounter)
            {
                case 0:
                    Level1Waves(F);
                    break;
                case 1:
                    Level2Waves(F);
                    break;
            }
        }

        private void Level1Waves(Form1 F)
        {
            int Roll = rand.Next(19);

            switch (Roll)
            {
                case 1:
                    if (!F.Special2)
                    {
                        EnemySpawnStyles.SpawnEnemies2(F);
                        F.Special2 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                case 2:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                case 4:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                case 5:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                case 7:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                case 8:
                    if (!F.Special2)
                    {
                        EnemySpawnStyles.SpawnEnemies2(F);
                        F.Special2 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                case 10:
                    if (!F.Special2)
                    {
                        EnemySpawnStyles.SpawnEnemies2(F);
                        F.Special2 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    }
                    break;
                default:
                    EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    break;
            }
        }


        private void Level2Waves(Form1 F)
        {
            int Roll = rand.Next(19);

            switch (Roll)
            {
                case 1:
                    if (!F.Special2)
                    {
                        EnemySpawnStyles.SpawnEnemies2(F);
                        F.Special2 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 2:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 4:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 5:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 7:
                    if (!F.Special1)
                    {
                        EnemySpawnStyles.SpawnEnemies(F);
                        F.Special1 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 8:
                    if (!F.Special2)
                    {
                        EnemySpawnStyles.SpawnEnemies2(F);
                        F.Special2 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 10:
                    if (!F.Special2)
                    {
                        EnemySpawnStyles.SpawnEnemies2(F);
                        F.Special2 = true;
                    }
                    else
                    {
                        EnemySpawnStyles.SpawnEnemy(18, F);
                    }
                    break;
                case 11:
                    EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    break;
                case 12:
                    EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    break;
                case 14:
                    EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    break;
                case 18:
                    EnemySpawnStyles.SpawnEnemiesSpecal3(F);
                    break;
                default:
                    EnemySpawnStyles.SpawnEnemy(18,F);
                    break;
            }
        }
    }
}
