﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
   public class Player
    {
        public PictureBox Body;
        public HitBox ColisionTester;
        public string CurrentPowerUp;
        public double Score;
        public int Kills;
        public int HitPoints;
        public string Name;
        public byte ShotCoolDown;
        public byte ShotCurrentCoolDown;

        public void CreatePlayer(Form PlayingFeild, string N)
        {
            Name = N;
            SetUpBody(Screen.PrimaryScreen.Bounds.Height, Screen.PrimaryScreen.Bounds.Width);
            Score = 0;
            Kills = 0;
            HitPoints = 3;
            ColisionTester = new HitBox();
            ShotCurrentCoolDown = 10;
        }

        private void SetUpBody(int H, int W)
        {
            Body = new PictureBox
            {
                Width = W / 24,
                Height = H / 26,
                Top = H - ((H / 18) + (H / 8)),
                Left = (W / 2) - (W / 20),
                BackColor = Color.Transparent
            };
            
        }

    }
}
