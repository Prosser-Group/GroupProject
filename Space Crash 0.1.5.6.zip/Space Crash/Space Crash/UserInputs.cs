﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Space_Crash
{
    public static class UserInputs
    {
        public static Keys KeyUp = Keys.Up;
        public static bool MoveUp = false;
        public static Keys KeyRight = Keys.Right;
        public static bool MoveRight = false;
        public static Keys KeyDown = Keys.Down;
        public static bool MoveDown = false;
        public static Keys KeyLeft = Keys.Left;
        public static bool MoveLeft = false;

        public static Keys KeyShot = Keys.Space;
        public static bool FireShot = false;
        public static Keys KeyMenu = Keys.Escape;

        public static Screen SelectedScreen = Screen.PrimaryScreen;

        public static bool DevMode = false;

        public static Keys PreventSpawn = Keys.F;
        public static Keys GodMode = Keys.G;
        public static Keys ClearWorld = Keys.H;
        public static Keys SpawnEnemyLine = Keys.D1;
        public static Keys SpawnEnemyLight = Keys.D2;
        public static Keys SpawnEnemyCracked = Keys.D3;
        public static Keys SpawnPowerUp = Keys.D4;

        public static void CreateSocreBord(Player P)
        {
            StreamReader reader;
            StreamWriter Writer;
            Player[] PlayerArray;

            Writer = File.CreateText("LeaderBoard.txt");
            Writer.Close();
            reader = File.OpenText("LeaderBoard.txt");

            string Temp;

            try
            {
                Temp = reader.ReadLine();
                if (Temp != null)
                {
                    int Temp2 = int.Parse(Temp);
                    PlayerArray = new Player[Temp2];
                    int counter = 0;
                    while (counter <= Temp2)
                    {
                        PlayerArray[counter].Name = reader.ReadLine();
                        PlayerArray[counter].Score = double.Parse(reader.ReadLine());
                        PlayerArray[counter].Kills = int.Parse(reader.ReadLine());
                        counter += 1;
                    }
                }
            }
            catch
            {

            }

           
        }

        private static void FindLargestPlayer(Player[] P)
        {
            int counter;
        }

    }
}
