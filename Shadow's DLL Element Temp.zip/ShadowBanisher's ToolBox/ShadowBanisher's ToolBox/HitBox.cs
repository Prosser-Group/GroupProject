﻿namespace ShadowBanisher_s_ToolBox
{
    public static class HitBox
    {
        public static bool FindCollison(this Vector_2 Player, Vector_2 Target)
        {
            bool Test = false;

            if ((Target.Top - Player.Height) <= Player.Top && (Target.Top + Target.Height) >= Player.Top && (Target.Left - Player.Width) <= Player.Left && (Target.Left + Target.Width) >= Player.Left)
            {
                Test = true;
            }

            return Test;
        }

    }
}
