﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    public class SightPoint
    {
        private int X = 0;
        private int Y = 0;

        public int Top
        {
            get
            {
                return X;
            }

            set
            {
                X = value;
            }
        }

        public int Left
        {
            get
            {
                return Y;
            }

            set
            {
                Y = value;
            }
        }
    }
}
