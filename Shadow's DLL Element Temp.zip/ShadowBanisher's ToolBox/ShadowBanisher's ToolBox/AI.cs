﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    public class AI
    {
        public bool PlayerControlled;

        private string LeaderID; //this is the ID for the leader of the AI if there is any If this is blank then it will have no leader

        public bool Combatable;
        public bool Interactable;
        public bool Merchant;
        public bool Chanagable;
        public bool OddBall; //This allows the AI to Randomly change if they need or can

        public bool Leader;
        

        public string DisplayLeaderID
        {
            get
            {
                if (Leader)
                {
                    return "Leader of " + LeaderID;
                }
                else
                {
                    return LeaderID;
                }
            }

            set
            {
                LeaderID = value;
            }
        }


        public void Change(bool DemandToChange)
        {
            if ((Chanagable && LeaderID != "" && DemandToChange) || (Chanagable && OddBall && LeaderID == ""))
            {
            
            }
        }

        public void SetAIsBeing(bool Odd, bool Combat, bool Interacter, bool Trader, bool Changer, bool lead, string leadID, byte changeLike, byte Hos, byte Loy, byte Hon)
        {
            
        }

    }
}
