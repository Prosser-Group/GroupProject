﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    public static class UserInputs
    {
        public static Keys KeyUp = Keys.W;
        public static bool MoveUp = false;
        public static Keys KeyRight = Keys.D;
        public static bool MoveRight = false;
        public static Keys KeyDown = Keys.S;
        public static bool MoveDown = false;
        public static Keys KeyLeft = Keys.A;
        public static bool MoveLeft = false;

        public static Keys KeyShot = Keys.Space;
        public static bool FireShot = false;
        public static Keys KeyMenu = Keys.Escape;

        public static Screen SelectedScreen = Screen.PrimaryScreen;
    }
}
