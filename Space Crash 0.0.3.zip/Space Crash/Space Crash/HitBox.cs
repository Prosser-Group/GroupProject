﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Space_Crash
{
   public class HitBox
    {
        

        private dynamic CheckUpperRightCorrner(PictureBox P)
        {

            Point Temp = new Point
            {
                X = (P.Width + P.Left),
                Y = (P.Top)
            };
            return Temp;
        }

        private dynamic CheckLowerLeftCorrner(PictureBox P)
        {
            Point Temp = new Point
            {
                X = (P.Left),
                Y = (P.Top + P.Height)
            };
            return Temp;
        }

        private dynamic CheckLowerRightCorrner(PictureBox P)
        {
            Point Temp = new Point
            {
                X = (P.Left + P.Width),
                Y = (P.Top + P.Height)
            };
            return Temp;
        }

        private dynamic FindCollison(PictureBox Player, PictureBox Target)
        {
            bool Test = false;
            Point TRC;
            Point LLC;
            Point LRC;

            Point TRC2;
            Point LLC2;
            Point LRC2;

            TRC=CheckUpperRightCorrner(Player);
            TRC2 = CheckUpperRightCorrner(Target);

            LLC = CheckLowerLeftCorrner(Player);
            LLC2 = CheckLowerLeftCorrner(Target);

            LRC = CheckLowerRightCorrner(Player);
            LRC2 = CheckLowerRightCorrner(Target);

            if (Player.Left <= TRC2.X && TRC.X >= Target.Left && TRC.Y >= LRC2.Y && TRC2.Y <= LRC.Y)
            {
                Test = true;
            }

            return Test;
        }

    }
}
