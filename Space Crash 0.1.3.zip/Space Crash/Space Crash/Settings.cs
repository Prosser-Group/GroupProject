﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class Settings : Form
    {
        Keys Up = UserInputs.KeyUp;
        Keys RightMove = UserInputs.KeyRight;
        Keys left = UserInputs.KeyLeft;

        Keys Down = UserInputs.KeyDown;
        Keys Shot = UserInputs.KeyShot;
        Keys ForceSpawn = UserInputs.PreventSpawn;

        Keys ClearSpawn = UserInputs.ClearWorld;
        Keys GodMode = UserInputs.GodMode;
        Keys KeyMenu = UserInputs.KeyMenu;

        Keys KeySpawnPowerUp = UserInputs.SpawnPowerUp;

        byte Temp;

        public Settings()
        {
            InitializeComponent();
            
        }

        private void Reset()
        {
            Up = UserInputs.KeyUp;
            RightMove = UserInputs.KeyRight;
            Down = UserInputs.KeyDown;
            left = UserInputs.KeyLeft;
            Shot = UserInputs.KeyShot;
            ForceSpawn = UserInputs.PreventSpawn;
            ClearSpawn = UserInputs.ClearWorld;
            GodMode = UserInputs.GodMode;
            KeyMenu = UserInputs.KeyMenu;

        }

        private void chkDevMode_CheckedChanged(object sender, EventArgs e)
        {
            switch (chkDevMode.Checked)
            {
                case true:
                    UserInputs.DevMode = true;
                    gpbDev.Show();
                    break;
                case false:
                    gpbDev.Hide();
                    UserInputs.DevMode = false;
                    break;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void RefreshKeys()
        {
            btnClear.Text = ClearSpawn.ToString();
            btnDown.Text = Down.ToString();
            btnFire.Text = Shot.ToString();

            btnGod.Text = GodMode.ToString();
            btnLeft.Text = left.ToString();
            btnRight.Text = RightMove.ToString();

            btnUp.Text = Up.ToString();
            btnSpawn.Text = ForceSpawn.ToString();
            btnMenu.Text = KeyMenu.ToString();

            btnPowerUp.Text = KeySpawnPowerUp.ToString();
        }

        private void AssignKeys()
        {
            UserInputs.KeyDown = Down;
            UserInputs.KeyLeft = left;
            UserInputs.KeyRight = RightMove;
            UserInputs.KeyShot = Shot;

            UserInputs.KeyUp = Up;
            UserInputs.PreventSpawn = ForceSpawn;
            UserInputs.GodMode = GodMode;
            UserInputs.ClearWorld = ClearSpawn;

            UserInputs.KeyMenu = KeyMenu;
            UserInputs.SpawnPowerUp = KeySpawnPowerUp;
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            RefreshKeys();
            Left = (Screen.PrimaryScreen.Bounds.Width / 2) - (Width / 2);
            Top = (Screen.PrimaryScreen.Bounds.Height / 2) - (Height / 2);
            chkDevMode.Checked = UserInputs.DevMode;
            switch (chkDevMode.Checked)
            {
                case true:
                    UserInputs.DevMode = true;
                    gpbDev.Show();
                    break;
                case false:
                    gpbDev.Hide();
                    UserInputs.DevMode = false;
                    break;
            }
        }

        private void Settings_KeyDown(object sender, KeyEventArgs e)
        {
            switch (Temp)
            {
                case 1:
                    Up = e.KeyCode;
                    break;
                case 2:
                    RightMove = e.KeyCode;
                    break;
                case 3:
                    Down = e.KeyCode;
                    break;
                case 4:
                    left = e.KeyCode;
                    break;
                case 5:
                    Shot = e.KeyCode;
                    break;
                case 6:
                    GodMode = e.KeyCode;
                    break;
                case 7:
                    ForceSpawn = e.KeyCode;
                    break;
                case 8:
                    ClearSpawn = e.KeyCode;
                    break;
                case 9:
                    KeyMenu = e.KeyCode;
                    break;
                case 10:
                    KeySpawnPowerUp = e.KeyCode;
                    break;
            }
            RefreshKeys();

            if (Temp == 0 && e.KeyCode == Keys.Scroll)
            {
                
                chkDevMode.Show();
            }
            Temp = 0;
            KeyPreview = false;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            Temp = 1;
            KeyPreview = true;
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            Temp = 2;
            KeyPreview = true;
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            Temp = 3;
            KeyPreview = true;
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            Temp = 4;
            KeyPreview = true;
        }

        private void btnFire_Click(object sender, EventArgs e)
        {
            Temp = 5;
            KeyPreview = true;
        }

        private void btnSpawn_Click(object sender, EventArgs e)
        {
            Temp = 7;
            KeyPreview = true;
        }

        private void btnGod_Click(object sender, EventArgs e)
        {
            Temp = 6;
            KeyPreview = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Temp = 8;
            KeyPreview = true;
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            Temp = 9;
            KeyPreview = true;
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            AssignKeys();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Reset();            
        }

        private void btnPowerUp_Click(object sender, EventArgs e)
        {
            Temp = 10;
            KeyPreview = true;
        }
    }
}
