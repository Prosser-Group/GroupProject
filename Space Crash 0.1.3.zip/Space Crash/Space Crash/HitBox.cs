﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Space_Crash
{
   public class HitBox
    {
        
        public dynamic FindCollison(PictureBox Player, PictureBox Target)
        {
            bool Test = false;

            if ((Target.Top - Player.Height) <= Player.Top && (Target.Top + Target.Height) >= Player.Top && (Target.Left - Player.Width) <= Player.Left && (Target.Left + Target.Width) >= Player.Left)
            {
                Test = true;
            }

            return Test;
        }

    }
}
