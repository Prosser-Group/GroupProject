﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class Menu : Form
    {

        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width / 6;
            Height = Screen.PrimaryScreen.Bounds.Height / 3;

            Left = (Screen.PrimaryScreen.Bounds.Width / 2) - (Width /2);
            Top = (Screen.PrimaryScreen.Bounds.Height / 2) - (Height / 2);

            picStart.Width = Width / 3;
            picStart.Height = Height / 8;
            picStart.Left = (Width / 2) - (picStart.Width / 2);
            picStart.Top = Height / 12;

            picSettings.Width = picStart.Width;
            picSettings.Height = picStart.Height;
            picSettings.Top = picStart.Top + picStart.Height + (picSettings.Height / 4);
            picSettings.Left = picStart.Left;

            picCredits.Width = picSettings.Width;
            picCredits.Height = picSettings.Height;
            picCredits.Left = picStart.Left;
            picCredits.Top = picSettings.Top + picSettings.Height + (picCredits.Height / 4);

            picClose.Width = picCredits.Width;
            picClose.Height = picCredits.Height;
            picClose.Left = picCredits.Left;
            picClose.Top = picCredits.Top + picCredits.Height + (picClose.Height / 4);
        }

        private void picStart_Click(object sender, EventArgs e)
        {
            Thread Game = new Thread(new ThreadStart(Program.StateGameThread));
            Game.Start();
            Close();
        }

        private void picSettings_Click(object sender, EventArgs e)
        {
            var frm = new Settings();
            Hide();
            frm.ShowDialog();
            Show();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void picCredits_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created By: Shadowbanisher, and Miley1128", "Credits");
        }
    }
}
