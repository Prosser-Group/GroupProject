﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

namespace Game__2_
{
    public static class Starting
    {
        public static void CreateDirectoryofGame()
        {
            StreamWriter S;
            StreamReader R;
            if (Directory.Exists(@"C:\Program Files\Shadow Games"))
            {
                if (Directory.Exists(@"C:\Program Files\Shadow Games\Game 2"))
                {
                    if (File.Exists(@"C:\Program Files\Shadow Games\Game 2\Finder.txt"))
                    {

                    }
                }
                Directory.CreateDirectory(@"C:\Program Files\Shadow Games");
                Directory.CreateDirectory(@"C:\Program Files\Shadow Games\Game 2");



            }
        }

        public static Stream GetEmbeddedResourceStream(string resourceName)
        {
            return Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
        }
    }
}
