﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Game__2_
{
    public class Entiety
    {
        public PictureBox Body;
        private Bitmap Selected;
        private Bitmap unselected;

        private string ID;
        public string Name;

        public bool Living;
        public bool Interactable;

        public double Health;


    }
}
