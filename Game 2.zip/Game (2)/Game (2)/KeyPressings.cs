﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game__2_
{
    public static class KeyPressings
    {
         static void HitTest(this Entiety I, Entiety H)
        {

        } 
        
        public static Form1 S;

        public static Keys Forward = Keys.W;
        public static Keys Backward = Keys.S;
        public static Keys Rightward = Keys.D;
        public static Keys Leftward = Keys.A;

        public static Keys MainMenu = Keys.Escape;

        public static bool blnForward = false;
        public static bool blnBackward = false;
        public static bool blnRightward = false;
        public static bool blnLeftward = false;


    }
}
