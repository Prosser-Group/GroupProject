﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game__2_
{
    public class Animals : Entiety
    {
        public bool Ai;

        private byte Agression; //This determines how likly an NPC will attack you or harm you
        private byte Loyalty; // How well they will follow you and to what extent
        private byte Packing; // How likly they will group in parties
        private byte Intelegence; // Can the do simple tasks or are the dumb as rocks and are vegibles
        private byte Exploration;
        private byte Honor;

    }
}

//These Ai bits will tell how a NPC will interact with the world
//AI with low Intelegence, and honor but have high agression, and packing will ball up and attack everything from friends and foe alike
