﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game__2_
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void Main_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == KeyPressings.Forward)
            {
                KeyPressings.blnForward = true;
            }

            if (e.KeyCode == KeyPressings.Leftward)
            {
                KeyPressings.blnLeftward = true;
            }

            if (e.KeyCode == KeyPressings.Rightward)
            {
                KeyPressings.blnRightward = true;
            }

            if (e.KeyCode == KeyPressings.Backward)
            {
                KeyPressings.blnBackward = true;
            }

            if (e.KeyCode == KeyPressings.MainMenu)
            {
                KeyPressings.S.Visible = true;
                Close();
            }
        }

        private void Main_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == KeyPressings.Forward)
            {
                KeyPressings.blnForward = false;
            }

            if (e.KeyCode == KeyPressings.Leftward)
            {
                KeyPressings.blnLeftward = false;
            }

            if (e.KeyCode == KeyPressings.Rightward)
            {
                KeyPressings.blnRightward = false;
            }

            if (e.KeyCode == KeyPressings.Backward)
            {
                KeyPressings.blnBackward = false;
            }
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            KeyPressings.S.Show();
        }
    }
}
