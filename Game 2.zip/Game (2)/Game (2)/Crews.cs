﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game__2_
{
    public class Crews
    {
        private string ID;
        public string Name;
        public string Motto;
        public string Description;

        private byte Aggression;
        private byte Diplomacy;
        private byte Economics;
        private byte Exploration;

    }
}
