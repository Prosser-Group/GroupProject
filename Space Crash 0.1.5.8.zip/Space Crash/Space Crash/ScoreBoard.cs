﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class ScoreBoard : Form
    {
        private PLayerScore[] DisplayPlayers;
        private Player[] playerArray;
        private int intNum;

        public ScoreBoard()
        {
            InitializeComponent();
        }

        private void ScoreBoard_Load(object sender, EventArgs e)
        {
            vsbPageScroller.Left = Width - 35;
            vsbPageScroller.Top = 0;
            vsbPageScroller.Height = Height - 35;
            int temp = UserInputs.FindNumberOfPlayersOnScoreBoard();
            playerArray = new Player[temp];
            playerArray = UserInputs.ReadScoreBoard();
            DisplayPlayers = new PLayerScore[temp];
            int counter = 0;
             while(counter < temp)
            {
                DisplayPlayers[counter] = new PLayerScore
                {
                    Name = playerArray[counter].Name,
                    Score = playerArray[counter].Score,
                    Kills = playerArray[counter].Kills
                };
                counter += 1;
            }
            intNum = temp;
            FindTopScore();
        }

        private void FindTopScore()
        {
            int counter = 0;
            int counter2 = 0;
            PLayerScore[] Temp = new PLayerScore[intNum];
            int[] saves = new int[intNum];
            bool Usable = false;

            while (counter < intNum)
            {
                while (counter2 < intNum)
                {
                    Usable = FindValues(counter2, saves);
                    if (Temp[counter] == null)
                    {
                        Temp[counter] = DisplayPlayers[counter2];
                        saves[counter] = counter2;
                    }
                    else if (Temp[counter].Score < DisplayPlayers[counter2].Score)
                    {
                        Temp[counter] = DisplayPlayers[counter2];
                        saves[counter] = counter2;
                    }
                    else if (Temp[counter].Score == DisplayPlayers[counter2].Score && DisplayPlayers[counter2].Kills > Temp[counter].Kills)
                    {
                        Temp[counter] = DisplayPlayers[counter2];
                        saves[counter] = counter2;
                    }

                    counter2 += 1;
                }

                counter += 1;
            }
        }

        private dynamic FindValues(int num, int[] Nums)
        {
            bool temp = true;
            int counter = 0;

            while (counter < intNum)
            {
                if (Nums[counter] == num)
                {
                    temp = false;
                    break;
                }
                counter += 1;
            }

            return temp;
        }

        private void DisplayScores()
        {

        }

    }
}
