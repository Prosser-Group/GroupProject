﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
   public class Enemy
    {
        public PictureBox Body;
        public HitBox CollisionTest;
        public string EnemyType = "";
        public bool Movement;
        public int EnemyCounter;
        public byte Firing;

        public virtual void CreateEnemy(Form F, string Type)
        {
            EnemyType = Type;
            SetUpBody(F.Height, F.Width, F);
            CollisionTest = new HitBox();
            Movement = false;
            switch (Type)
            {
                case "S1":
                    Firing = 0;
                    break;
                case "S2":
                    Firing = 0;
                    break;
            }
        }

        private void SetUpBody(int H, int W, Form F)
        {
            Body = new PictureBox
            {
                Width = W / 24,
                Height = H / 26,
                BackColor = SystemColors.ButtonShadow,
                Parent = F
            };

        }

    }
}
