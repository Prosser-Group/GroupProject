﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    
    class Bosses : Enemy
    {
        public int HitPoints;

        public override void CreateEnemy(Form F, string Type)
        {
            EnemyType = Type;
            CollisionTest = new HitBox();
            Movement = false;
            HitPoints = 50;
        }

        private void SetBoss()
        {
            Body.Width = Screen.PrimaryScreen.Bounds.Width;
            Body.Height = Screen.PrimaryScreen.Bounds.Height / 4;
            Body.Left = 0;
            Body.Top = -(Body.Height);
        }
    }
}
