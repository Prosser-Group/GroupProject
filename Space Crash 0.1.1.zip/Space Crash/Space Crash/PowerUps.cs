﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    public class PowerUps
    {
        public HitBox Colider;
        public string Name;
        public PictureBox Body;

        public void SetSpecial(string N,int X, int Y, PictureBox P)
        {
            Body = new PictureBox
            {
                Width = (Y / 80) / 2,
                Height = (X / 48) / 2,
                Left = P.Left + (P.Width /2),
                Top = P.Top + (P.Height/2),
                BackColor = SystemColors.ButtonShadow
            };
            Name = N;
            Colider = new HitBox();
        }

        public void CreateBlank(string N, int X, int Y)
        {
            Body = new PictureBox
            {
                Width = (X / 80) / 2,
                Height = (Y / 48) / 2,
                Left = (X /2) - (((X / 80) / 2) / 2),
                Top = 0,
                BackColor = SystemColors.ButtonShadow
            };
            Name = N;
            Colider = new HitBox();
        }
    }
}
