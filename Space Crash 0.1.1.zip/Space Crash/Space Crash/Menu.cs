﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class Menu : Form
    {

        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width / 4;
            Height = Screen.PrimaryScreen.Bounds.Height / 2;
            Left = (Screen.PrimaryScreen.Bounds.Width / 2) - (Width /2);
            Top = (Screen.PrimaryScreen.Bounds.Height / 2) - (Height / 2);
        }

        private void picStart_Click(object sender, EventArgs e)
        {
            Thread Game = new Thread(new ThreadStart(Program.StateGameThread));
            Game.Start();
            Close();
        }

        private void picSettings_Click(object sender, EventArgs e)
        {
            var frm = new Settings();
            Hide();
            frm.ShowDialog();
            Show();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void picCredits_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created By: Shadowbanisher, and Miley1128", "Credits");
        }
    }
}
