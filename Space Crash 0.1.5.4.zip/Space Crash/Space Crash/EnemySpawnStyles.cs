﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Crash
{
    public static class EnemySpawnStyles
    {

        //base Line Enemy
        public static void SpawnEnemy(int I, Form1 ActiveForm)
        {
            int Counter = 0;
            while (Counter <= I)
            {
                ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
                ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "N");
                ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20) * Counter) - 24;
                ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
                Counter += 1;
                ActiveForm.CurrentEnemy += 1;
                if (ActiveForm.CurrentEnemy == 254)
                {
                    ActiveForm.CurrentEnemy = 0;
                }
            }
        }

        //Light Enemy
        public static void SpawnEnemies(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "C");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20)) - 24;
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        //Crack Enemy
        public static void SpawnEnemies2(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "K");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width /= 2;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20)) - 24;
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        //Shock Enemy
        public static void SpawnRandomSideSpecal3(Form1 ActiveForm)
        {
            switch (ActiveForm.Special3)
            {
                case true:
                    SpawnEnemiesSpecal3(ActiveForm);
                    break;
                case false:
                    SpawnEnemiesSpecal31(ActiveForm);
                    break;
            }
        }

        public static void SpawnEnemiesSpecal3(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "S1");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width /= 2;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (ActiveForm.Width - (ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 10)) - ((ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width + 20)) - 24;
            ActiveForm.Special3 = false;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Movement = false;

            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        public static void SpawnEnemiesSpecal31(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Enemy();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "S2");
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width /= 2;

            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Left = (0 + ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body.Width);
            ActiveForm.Special3 = true;
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].Movement = false;

            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

        public static void SpawnBoss1(Form1 ActiveForm)
        {
            ActiveForm.Enemies[ActiveForm.CurrentEnemy] = new Bosses();
            ActiveForm.Enemies[ActiveForm.CurrentEnemy].CreateEnemy(ActiveForm, "A");
            ActiveForm.Controls.Add(ActiveForm.Enemies[ActiveForm.CurrentEnemy].Body);
            ActiveForm.CurrentEnemy += 1;
            if (ActiveForm.CurrentEnemy == 254)
            {
                ActiveForm.CurrentEnemy = 0;
            }
        }

    }
}
