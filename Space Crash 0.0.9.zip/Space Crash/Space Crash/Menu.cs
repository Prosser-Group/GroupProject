﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class Menu : Form
    {


        private bool Clicks = false;
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width / 4;
            Height = Screen.PrimaryScreen.Bounds.Height / 2;
            Left = 0;
            Top = 0;
        }

        private void Menu_MouseDown(object sender, MouseEventArgs e)
        {
            switch (Clicks)
            {
                case true:
                    Clicks = false;
                    break;
                case false:
                    Clicks = true;
                    break;
            }

        }

        private void Menu_MouseMove(object sender, MouseEventArgs e)
        {
            if (Clicks == true)
            {
                Left = e.X;
                Top = e.Y;
            }
        }

        private void picStart_Click(object sender, EventArgs e)
        {
            Thread Game = new Thread(new ThreadStart(Program.StateGameThread));
            Game.Start();
            Close();
        }

        private void picSettings_Click(object sender, EventArgs e)
        {
            var frm = new Settings();
            Hide();
            frm.ShowDialog();
            Show();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
