﻿namespace Space_Crash
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picStart = new System.Windows.Forms.PictureBox();
            this.picSettings = new System.Windows.Forms.PictureBox();
            this.picCredits = new System.Windows.Forms.PictureBox();
            this.picClose = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picStart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSettings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCredits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            this.SuspendLayout();
            // 
            // picStart
            // 
            this.picStart.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picStart.Location = new System.Drawing.Point(217, 12);
            this.picStart.Name = "picStart";
            this.picStart.Size = new System.Drawing.Size(100, 50);
            this.picStart.TabIndex = 0;
            this.picStart.TabStop = false;
            this.picStart.Click += new System.EventHandler(this.picStart_Click);
            // 
            // picSettings
            // 
            this.picSettings.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.picSettings.Location = new System.Drawing.Point(217, 68);
            this.picSettings.Name = "picSettings";
            this.picSettings.Size = new System.Drawing.Size(100, 50);
            this.picSettings.TabIndex = 1;
            this.picSettings.TabStop = false;
            this.picSettings.Click += new System.EventHandler(this.picSettings_Click);
            // 
            // picCredits
            // 
            this.picCredits.BackColor = System.Drawing.SystemColors.ControlText;
            this.picCredits.Location = new System.Drawing.Point(217, 124);
            this.picCredits.Name = "picCredits";
            this.picCredits.Size = new System.Drawing.Size(100, 50);
            this.picCredits.TabIndex = 2;
            this.picCredits.TabStop = false;
            // 
            // picClose
            // 
            this.picClose.BackColor = System.Drawing.SystemColors.ControlLight;
            this.picClose.Location = new System.Drawing.Point(217, 180);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(100, 50);
            this.picClose.TabIndex = 3;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 386);
            this.Controls.Add(this.picClose);
            this.Controls.Add(this.picCredits);
            this.Controls.Add(this.picSettings);
            this.Controls.Add(this.picStart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Menu_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Menu_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.picStart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSettings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCredits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picStart;
        private System.Windows.Forms.PictureBox picSettings;
        private System.Windows.Forms.PictureBox picCredits;
        private System.Windows.Forms.PictureBox picClose;
    }
}