﻿namespace Group_Project_Game
{
    partial class Startup_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.picSettings = new System.Windows.Forms.PictureBox();
            this.picCredits = new System.Windows.Forms.PictureBox();
            this.picStartGame = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSettings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCredits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStartGame)).BeginInit();
            this.SuspendLayout();
            // 
            // picLogo
            // 
            this.picLogo.BackColor = System.Drawing.SystemColors.ControlText;
            this.picLogo.Location = new System.Drawing.Point(116, 12);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(100, 50);
            this.picLogo.TabIndex = 4;
            this.picLogo.TabStop = false;
            // 
            // picExit
            // 
            this.picExit.BackColor = System.Drawing.Color.Teal;
            this.picExit.Image = global::Group_Project_Game.Properties.Resources.ExitButton;
            this.picExit.Location = new System.Drawing.Point(0, 168);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(128, 32);
            this.picExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picExit.TabIndex = 3;
            this.picExit.TabStop = false;
            this.picExit.Click += new System.EventHandler(this.picExit_Click);
            // 
            // picSettings
            // 
            this.picSettings.BackColor = System.Drawing.Color.Aquamarine;
            this.picSettings.Image = global::Group_Project_Game.Properties.Resources.Settings;
            this.picSettings.Location = new System.Drawing.Point(0, 112);
            this.picSettings.Name = "picSettings";
            this.picSettings.Size = new System.Drawing.Size(100, 50);
            this.picSettings.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSettings.TabIndex = 2;
            this.picSettings.TabStop = false;
            this.picSettings.Click += new System.EventHandler(this.picSettings_Click);
            // 
            // picCredits
            // 
            this.picCredits.BackColor = System.Drawing.Color.Crimson;
            this.picCredits.Image = global::Group_Project_Game.Properties.Resources.Credits;
            this.picCredits.Location = new System.Drawing.Point(0, 56);
            this.picCredits.Name = "picCredits";
            this.picCredits.Size = new System.Drawing.Size(100, 50);
            this.picCredits.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCredits.TabIndex = 1;
            this.picCredits.TabStop = false;
            this.picCredits.Click += new System.EventHandler(this.picCredits_Click);
            // 
            // picStartGame
            // 
            this.picStartGame.BackColor = System.Drawing.SystemColors.ControlLight;
            this.picStartGame.Image = global::Group_Project_Game.Properties.Resources.StartButton;
            this.picStartGame.Location = new System.Drawing.Point(0, 0);
            this.picStartGame.Name = "picStartGame";
            this.picStartGame.Size = new System.Drawing.Size(100, 50);
            this.picStartGame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picStartGame.TabIndex = 0;
            this.picStartGame.TabStop = false;
            this.picStartGame.Click += new System.EventHandler(this.picStartGame_Click);
            // 
            // Startup_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BackgroundImage = global::Group_Project_Game.Properties.Resources.archives_ngc6946;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.picExit);
            this.Controls.Add(this.picSettings);
            this.Controls.Add(this.picCredits);
            this.Controls.Add(this.picStartGame);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Startup_Menu";
            this.Text = "Startup_Menu";
            this.Load += new System.EventHandler(this.Startup_Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSettings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCredits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStartGame)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picStartGame;
        private System.Windows.Forms.PictureBox picCredits;
        private System.Windows.Forms.PictureBox picSettings;
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.PictureBox picLogo;
    }
}