﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Game
{
    public partial class Startup_Menu : Form
    {
        public Startup_Menu()
        {
            InitializeComponent();
        }

        private void Startup_Menu_Load(object sender, EventArgs e)
        {
            Height = Screen.PrimaryScreen.Bounds.Height/ 2;
            Width = Screen.PrimaryScreen.Bounds.Width / 4;
            Left = (Screen.PrimaryScreen.Bounds.Width / 2) - (Width / 2);
            Top = (Screen.PrimaryScreen.Bounds.Height / 2) - (Height / 2);
            ButtonSetup();
        }

        private void ButtonSetup()
        {
            picLogo.Top = 0;
            picLogo.Left = 0;
            picLogo.Width = Width;
            picLogo.Height = (Height / 4);

            picStartGame.Height = Height / 12;
            picStartGame.Width = Width / 3;
            picStartGame.Left = (Width / 2) - (picStartGame.Width / 2);
            picStartGame.Top = 20 + picLogo.Height;

            picSettings.Height = picStartGame.Height;
            picSettings.Width = picStartGame.Width;
            picSettings.Left = picStartGame.Left;
            picSettings.Top = picStartGame.Top + picSettings.Height + 55;

            picExit.Height = picStartGame.Height;
            picExit.Width = picStartGame.Width;
            picExit.Left = picStartGame.Left;
            picExit.Top = picSettings.Top + picExit.Height + 55;

            picCredits.Height = picStartGame.Height;
            picCredits.Width = picStartGame.Width;
            picCredits.Left = Width - picCredits.Width;
            picCredits.Top = Height - picCredits.Height;
        }

        private void picStartGame_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void picExit_Click(object sender, EventArgs e)
        {
            Form1.ClosingAllForms = true;
            Application.Exit();
        }

        private void picCredits_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Created By: Shadowbanisher, and Miley1128");
        }

        private void picSettings_Click(object sender, EventArgs e)
        {
            MessageBox.Show("It currently has no settings");
        }
    }
}
