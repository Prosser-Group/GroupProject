﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Game
{
    public partial class Main_Menu : Form
    {
        public Main_Menu()
        {
            InitializeComponent();
        }

        private void Main_Menu_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width/5;
            Height = Screen.PrimaryScreen.Bounds.Height / 4;
            Left = Screen.PrimaryScreen.Bounds.Width - Width;
            Top = Screen.PrimaryScreen.Bounds.Height - ((Screen.PrimaryScreen.Bounds.Height / 12)+ Height);
            SetUpButtons();
        }

        private void SetUpButtons()
        {
            picReturn.Width = Width / 2;
            picReturn.Height = Height / 6;
            picReturn.Top = 0 + picReturn.Height;
            picReturn.Left = (Width / 2) - (picReturn.Width / 2);

            picQuit.Width = picReturn.Width;
            picQuit.Height = picReturn.Height;
            picQuit.Left = picReturn.Left;
            picQuit.Top = picReturn.Top + picReturn.Height + picReturn.Height;

        }

        private void picReturn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void picQuit_Click(object sender, EventArgs e)
        {
            Form1.MainMenuOpen = true;            
            Close();
        }

        private void Main_Menu_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
        }
    }
}
