﻿namespace Group_Project_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrShots = new System.Windows.Forms.Timer(this.components);
            this.Movement = new System.Windows.Forms.Timer(this.components);
            this.pnlUi = new System.Windows.Forms.Panel();
            this.picMainMenu = new System.Windows.Forms.PictureBox();
            this.ShotCoolDownTimer = new System.Windows.Forms.Timer(this.components);
            this.picPlayer = new System.Windows.Forms.PictureBox();
            this.tmrEnemy = new System.Windows.Forms.Timer(this.components);
            this.EnemySpawn = new System.Windows.Forms.Timer(this.components);
            this.pnlUi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMainMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // tmrShots
            // 
            this.tmrShots.Enabled = true;
            this.tmrShots.Interval = 10;
            this.tmrShots.Tick += new System.EventHandler(this.tmrShots_Tick);
            // 
            // Movement
            // 
            this.Movement.Enabled = true;
            this.Movement.Interval = 10;
            this.Movement.Tick += new System.EventHandler(this.Movement_Tick);
            // 
            // pnlUi
            // 
            this.pnlUi.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnlUi.Controls.Add(this.picMainMenu);
            this.pnlUi.Location = new System.Drawing.Point(248, 282);
            this.pnlUi.Name = "pnlUi";
            this.pnlUi.Size = new System.Drawing.Size(200, 100);
            this.pnlUi.TabIndex = 2;
            // 
            // picMainMenu
            // 
            this.picMainMenu.BackColor = System.Drawing.SystemColors.ControlText;
            this.picMainMenu.Location = new System.Drawing.Point(80, 27);
            this.picMainMenu.Name = "picMainMenu";
            this.picMainMenu.Size = new System.Drawing.Size(100, 50);
            this.picMainMenu.TabIndex = 3;
            this.picMainMenu.TabStop = false;
            this.picMainMenu.Click += new System.EventHandler(this.picMainMenu_Click);
            // 
            // ShotCoolDownTimer
            // 
            this.ShotCoolDownTimer.Interval = 125;
            this.ShotCoolDownTimer.Tick += new System.EventHandler(this.ShotCoolDownTimer_Tick);
            // 
            // picPlayer
            // 
            this.picPlayer.BackColor = System.Drawing.Color.Transparent;
            this.picPlayer.Image = global::Group_Project_Game.Properties.Resources.Player;
            this.picPlayer.Location = new System.Drawing.Point(130, 85);
            this.picPlayer.Name = "picPlayer";
            this.picPlayer.Size = new System.Drawing.Size(100, 50);
            this.picPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPlayer.TabIndex = 0;
            this.picPlayer.TabStop = false;
            // 
            // tmrEnemy
            // 
            this.tmrEnemy.Enabled = true;
            this.tmrEnemy.Interval = 250;
            this.tmrEnemy.Tick += new System.EventHandler(this.tmrEnemy_Tick);
            // 
            // EnemySpawn
            // 
            this.EnemySpawn.Enabled = true;
            this.EnemySpawn.Interval = 5000;
            this.EnemySpawn.Tick += new System.EventHandler(this.EnemySpawn_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 488);
            this.Controls.Add(this.pnlUi);
            this.Controls.Add(this.picPlayer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.pnlUi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picMainMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrShots;
        private System.Windows.Forms.PictureBox picPlayer;
        private System.Windows.Forms.Timer Movement;
        private System.Windows.Forms.Panel pnlUi;
        private System.Windows.Forms.Timer ShotCoolDownTimer;
        private System.Windows.Forms.PictureBox picMainMenu;
        private System.Windows.Forms.Timer tmrEnemy;
        private System.Windows.Forms.Timer EnemySpawn;
    }
}

