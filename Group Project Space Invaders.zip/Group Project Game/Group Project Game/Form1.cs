﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Group_Project_Game
{
    public partial class Form1 : Form
    {
        private byte CooldownCounter = 0;
        private byte EnemyMovementCounter = 0;
        private int EnemySpawnCounter = 0;
        private double Score = 0;

        private Random Rand = new Random();

        private bool LeftMove = false;
        private bool RightMove = false;
        private bool DownMove = false;
        private bool UpMove = false;

        private byte[] EnemyRandomShots = new byte[5];

        private int EnemyLocation = 200;

        //private SoundPlayer PlayerShotSound = new SoundPlayer(Properties.Resources.Project_2);

        private bool MovingUp = false;
        private bool MovingLeft = false;
        private bool MovingRight = false;
        private bool MovingDown = false;

        private Control[] ShotLocations = new Control[255];

        private byte FiredShots = 0;

        private byte EnemyShots = 0;

        private byte EnemyCounter = 0;

        private bool ShotCooldown = false;

        private byte EnemyShotTimer = 25;
        private byte EnemyShotCounter = 0;

        private Control[] EnemyShotLocation = new Control[255];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width;
            Height = Screen.PrimaryScreen.Bounds.Height;
            Top = 0;
            Left = 0;

            UISetup();
            Player_Setup();
            SaveShots();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            TestLocation();
            if (e.KeyCode == Keys.Escape)
            {
                MenuSetUp();
            }
            else if (e.KeyCode == Keys.Left)
            {
                if (LeftMove == false)
                {
                    MovingLeft = true;
                }

            }
            else if (e.KeyCode == Keys.Right)
            {
                if (RightMove == false)
                {
                    MovingRight = true;
                }

            }
            else if (e.KeyCode == Keys.Up)
            {
                if (UpMove == false)
                {
                    MovingUp = true;
                }
            }
            else if (e.KeyCode == Keys.Down)
            {
                if (DownMove == false)
                {
                    MovingDown = true;
                }
            }
            else if (e.KeyCode == Keys.Space)
            {
                if (ShotCooldown == false)
                {
                    FireShot();
                }
            }
            else if (e.KeyCode == Keys.U)
            {
                EnemyShotPlanning();
            } 
            UpMove = false;
            DownMove = false;
            RightMove = false;
            LeftMove = false;
        }

        private void Player_Setup()
        {
            picPlayer.Height = Height / 24;
            picPlayer.Width = Width / 24;
            picPlayer.Left = (Width / 2) - (picPlayer.Width / 2);
            picPlayer.Top = Height - (30 + picPlayer.Height + pnlUi.Height);
            Bitmap RedsE = new Bitmap (picPlayer.Image);

            RedsE.MakeTransparent(Color.White);
            RedsE.MakeTransparent(RedsE.GetPixel(0, 0));

            picPlayer.Image = RedsE;
            
        }

        private void UISetup()
        {
            pnlUi.Width = Width;
            pnlUi.Height = Height / 12;
            pnlUi.Top = Height - pnlUi.Height;
            pnlUi.Left = 0;

            picMainMenu.Width = Width / 24;
            picMainMenu.Height = pnlUi.Height;
            picMainMenu.Left = pnlUi.Width - picMainMenu.Width;
            picMainMenu.Top = 0;

            lblScore.Top = (pnlUi.Height / 2) - (lblScore.Height / 2);
            lblScore.Left = 0 + (pnlUi.Width / 20);

            lblTagScore.Top = (lblScore.Top - lblTagScore.Height) - 2;
            lblTagScore.Left = lblScore.Left;
            lblTagScore.Text = "Score";
            
        }

        private void TestLocation()
        {
            if (picPlayer.Left + picPlayer.Width >= Width)
            {
                RightMove = true;
            }
            else if (picPlayer.Left <= 0)
            {
                LeftMove = true;
            }
            else if (picPlayer.Top + picPlayer.Height >= Height - pnlUi.Height)
            {
                DownMove = true;
            }
            else if (picPlayer.Top <= Height - (400 + pnlUi.Height))
            {
                UpMove = true;
            }
        }

        private void FireShot()
        {
            PictureBox Shots = new PictureBox();
            Shots.Width = picPlayer.Width / 5;
            Shots.Height = picPlayer.Height / 2;
            Shots.Left = (picPlayer.Left + (picPlayer.Width / 2)) - (Shots.Width/2);
            Shots.Top = picPlayer.Top - Shots.Height;
            Shots.SizeMode = PictureBoxSizeMode.StretchImage;
            Bitmap Temp = Properties.Resources.PlayerShot;
            Temp.MakeTransparent(Temp.GetPixel(0, 0));
            Shots.Image = Temp;
            Shots.BackColor = picPlayer.BackColor;

            Shots.Name = "picshots" + FiredShots.ToString("");
            if (FiredShots == 254)
            {
                FiredShots = 0;
            }
            else
            {
                FiredShots += 1;
            }
            //PlayerShotSound.Play();
            Controls.Add(Shots);

            ShotLocations[FiredShots] = Shots;

            ShotCooldown = true;
        }

        private void Shot_Move()
        {
            byte counter = 0;
            do
            {
                if (ShotLocations[counter] != null)
                {  


                    if (ShotLocations[counter].Top <= 0)
                    {
                        Controls.Remove(ShotLocations[counter]);
                        ShotLocations[counter] = null;
                    }
                    else
                    {
                        ShotLocations[counter].Top -= 5;
                    }
                }

                if (EnemyShotLocation[counter] != null)
                {


                    if (EnemyShotLocation[counter].Top >= Height)
                    {
                        Controls.Remove(EnemyShotLocation[counter]);
                        EnemyShotLocation[counter] = null;
                    }
                    else
                    {
                        EnemyShotLocation[counter].Top += 5;
                    }
                }

                counter += 1;
            } while (counter != 255);
            ShotColisonTest();
        }

        private void Movement_Tests()
        {
            TestLocation();
            if (MovingLeft == true && LeftMove == false)
            {
                picPlayer.Left -= 5;
            }
            if (MovingRight == true && RightMove == false)
            {
                picPlayer.Left += 5;
            }
            if (MovingDown == true && DownMove == false)
            {
                picPlayer.Top += 5;
            }
            if (MovingUp == true && UpMove == false)
            {
                picPlayer.Top -= 5;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            MovingDown = false;
            MovingLeft = false;
            MovingRight = false;
            MovingUp = false;

        }

        private void picMainMenu_Click(object sender, EventArgs e)
        {
            MenuSetUp();
        }

        private void MenuSetUp()
        {
            var FrmMenu = new Main_Menu();
            PauseGame();
            FrmMenu.ShowDialog();
            StartGame();
        }

        private void PauseGame()
        {
            GameTimer.Stop();
        }

        private void StartGame()
        {
            GameTimer.Start();
        }

        private void EnemiesSpawning()
        {
            byte Counter = 0;
            do
            {
                PictureBox Enemey = new PictureBox();
                Enemey.Width = picPlayer.Width;
                Enemey.Height = picPlayer.Height;



                Enemey.Left = EnemyLocation;
                EnemyLocation += Enemey.Width + 20;
                if (Width - Enemey.Width <= EnemyLocation)
                {
                    EnemyLocation = Enemey.Width;
                }

                Enemey.Top = -Enemey.Height;
                Enemey.BackColor = picPlayer.BackColor;
                Enemey.SizeMode = PictureBoxSizeMode.StretchImage;

                Enemey.Image = Properties.Resources.Badguy1;
                Enemey.Name = "picEnemy" + EnemyCounter.ToString();
                if (EnemyCounter >= 254)
                {
                    EnemyCounter = 0;
                }
                else
                {
                    EnemyCounter += 1;
                }
                Controls.Add(Enemey);
                Counter += 1;
            } while (Counter != 16);
        }

        private void Enemy_Move()
        {
            byte counter = 0;
            bool GameLose = false;
            do
            {

                if (Controls.ContainsKey("picEnemy" + counter.ToString("")) == true)
                {
                    Control[] Temporary = Controls.Find("picEnemy" + counter.ToString(""), true);
                    Control Temps = Temporary[0];
                    if (Temps.Top == Height)
                    {
                        Controls.Remove(Temps);
                    }
                    else
                    {
                        Temps.Top += 5;
                    }
                }
                counter += 1;
            } while (counter <= 254);

            if (GameLose == true)
            {
                MessageBox.Show("Game Over");
            }
        }

        //Test to see if shot has colided with anything
        private void ShotColisonTest()
        {
            byte Counter1 = 0;
            byte Counter2 = 0;
            Control[] Temporary1;
            Control Temps1 = null;
            do
            {
                if (Controls.ContainsKey("picEnemy" + Counter1.ToString("")) == true)
                {
                    Temporary1 = Controls.Find("picEnemy" + Counter1.ToString(""), true);
                    Temps1 = Temporary1[0];
                }

                do
                {
                    
                    if (Temps1 != null)
                    {
                        if (ShotLocations[Counter2] != null)
                        {
                            if ((Temps1.Top - ShotLocations[Counter2].Height) + 4 <= ShotLocations[Counter2].Top && (Temps1.Top + Temps1.Height) - 2 >= ShotLocations[Counter2].Top && (Temps1.Left - ShotLocations[Counter2].Width) + 4 <= ShotLocations[Counter2].Left && (Temps1.Left + Temps1.Width) - 2 >= ShotLocations[Counter2].Left)
                            {
                                Controls.Remove(Temps1);
                                Controls.Remove(ShotLocations[Counter2]);
                                ShotLocations[Counter2] = null;
                                Score += 100;
                            }
                        }
                    }
                    else
                    {
                        Counter2 = 254;
                    }
                    Counter2 += 1;
                } while (Counter2 <= 254);
                Counter1 += 1;
                Counter2 = 0;
            } while (Counter1 <= 254);
        }

        private void SaveShots()
        {
            byte Counter = 0;
            do
            {

                ShotLocations[Counter] = null;
                EnemyShotLocation[Counter] = null;
                Counter += 1;

            } while (Counter >= 254);
        }

        private void EnemyShotPlanning()
        {
            byte counter = 0;
            RandomizeEnemyShots();
            do
            {
                if (Controls.ContainsKey("picEnemy" + counter.ToString("")) == true)
            {
                Control[] Temporary = Controls.Find("picEnemy" + counter.ToString(""), true);
                Control Temps = Temporary[0];
                byte TempCount = 0;
                    do
                    {
                        if (counter == EnemyRandomShots[TempCount])
                        {
                            EnemyShooting(Temps);
                        }
                        TempCount += 1;
                    } while (TempCount <= 4);                
            }
                counter += 1;
            } while (counter <= 254);
        }

        private void EnemyShooting(Control Enemy)
        {
            PictureBox Shots = new PictureBox();
            Shots.Width = Enemy.Width / 5;
            Shots.Height = Enemy.Height / 2;
            Shots.Left = (Enemy.Left + (Enemy.Width / 2)) - (Shots.Width / 2);
            Shots.Top = Enemy.Top + Enemy.Height;
            Shots.SizeMode = PictureBoxSizeMode.StretchImage;
            Bitmap Temp = Properties.Resources.EnemyShot;
            Temp.MakeTransparent(Temp.GetPixel(0, 0));
            Shots.Image = Temp;
            Shots.BackColor = picPlayer.BackColor;

            Shots.Name = "picshotsenemy" + EnemyShots.ToString("");
            if (EnemyShots == 254)
            {
                EnemyShots = 0;
            }
            else
            {
                EnemyShots += 1;
            }
            Controls.Add(Shots);
            EnemyShotTimer = byte.Parse((Rand.Next(50) + 50).ToString());

            EnemyShotLocation[EnemyShots] = Shots;
        }

        private void EnemyFormation()
        {

        }

        private void RandomizeEnemyShots()
        {
            byte Counter = 0;
            do
            {
                EnemyRandomShots[Counter] = byte.Parse(Rand.Next(254).ToString());
                Counter += 1;
            } while (Counter <= 4);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            Movement_Tests();
            Shot_Move();

            if (EnemyMovementCounter == 20)
            {
                Enemy_Move();
                EnemyMovementCounter = 0;
            }
            else
            {
                EnemyMovementCounter += 1;
            }

            if (EnemySpawnCounter == 300)
            {
                EnemiesSpawning();
                EnemySpawnCounter = 0;
            }
            else
            {
                EnemySpawnCounter += 1;
            }

            if (CooldownCounter == 15 && ShotCooldown == true)
            {
                ShotCooldown = false;
                CooldownCounter = 0;
            }
            else if ( ShotCooldown == true)
            {
                CooldownCounter += 1;
            }

            lblScore.Text = Score.ToString();

            if (EnemyShotCounter == EnemyShotTimer)
            {
                EnemyShotPlanning();
                EnemyShotCounter = 0;
            }
            else
            {
                EnemyShotCounter += 1;
            }
        }
    }

}
