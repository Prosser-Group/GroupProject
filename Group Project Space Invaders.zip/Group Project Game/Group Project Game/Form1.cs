﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Group_Project_Game
{
    public partial class Form1 : Form
    {
        private bool LeftMove = false;
        private bool RightMove = false;
        private bool DownMove = false;
        private bool UpMove = false;

        private int EnemyLocation = 20;

        //private SoundPlayer PlayerShotSound = new SoundPlayer(Properties.Resources.Project_2);

        private bool MovingUp = false;
        private bool MovingLeft = false;
        private bool MovingRight = false;
        private bool MovingDown = false;

        private byte FiredShots = 0;
        private byte EnemyCounter = 0;

        private bool ShotCooldown = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width;
            Height = Screen.PrimaryScreen.Bounds.Height;
            Top = 0;
            Left = 0;

            UISetup();
            Player_Setup();

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            TestLocation();
            if (e.KeyCode == Keys.Escape)
            {
                MenuSetUp();
            }
            else if (e.KeyCode == Keys.Left)
            {
                if (LeftMove == false)
                {
                    MovingLeft = true;
                }

            }
            else if (e.KeyCode == Keys.Right)
            {
                if (RightMove == false)
                {
                    MovingRight = true;
                }

            }
            else if (e.KeyCode == Keys.Up)
            {
                if (UpMove == false)
                {
                    MovingUp = true;
                }
            }
            else if (e.KeyCode == Keys.Down)
            {
                if (DownMove == false)
                {
                    MovingDown = true;
                }
            }
            else if (e.KeyCode == Keys.Space)
            {
                if (ShotCooldown == false)
                {
                    FireShot();
                }
            }
            else
            {

            }
            UpMove = false;
            DownMove = false;
            RightMove = false;
            LeftMove = false;
        }

        private void Player_Setup()
        {
            picPlayer.Height = Height / 24;
            picPlayer.Width = Width / 24;
            picPlayer.Left = (Width / 2) - (picPlayer.Width / 2);
            picPlayer.Top = Height - (30 + picPlayer.Height + pnlUi.Height);
            Bitmap RedsE = new Bitmap (picPlayer.Image);

            RedsE.MakeTransparent(Color.White);
            RedsE.MakeTransparent(RedsE.GetPixel(0, 0));

            picPlayer.Image = RedsE;
            
        }

        private void UISetup()
        {
            pnlUi.Width = Width;
            pnlUi.Height = Height / 12;
            pnlUi.Top = Height - pnlUi.Height;
            pnlUi.Left = 0;

            picMainMenu.Width = Width / 24;
            picMainMenu.Height = pnlUi.Height;
            picMainMenu.Left = pnlUi.Width - picMainMenu.Width;
            picMainMenu.Top = 0;
        }

        private void TestLocation()
        {
            if (picPlayer.Left + picPlayer.Width >= Width)
            {
                RightMove = true;
            }
            else if (picPlayer.Left <= 0)
            {
                LeftMove = true;
            }
            else if (picPlayer.Top + picPlayer.Height >= Height - pnlUi.Height)
            {
                DownMove = true;
            }
            else if (picPlayer.Top <= Height - (400 + pnlUi.Height))
            {
                UpMove = true;
            }
        }

        private void FireShot()
        {
            PictureBox Shots = new PictureBox();
            Shots.Width = picPlayer.Width / 4;
            Shots.Height = picPlayer.Height / 2;
            Shots.Left = (picPlayer.Left + (picPlayer.Width / 2)) - (Shots.Width/2);
            Shots.Top = picPlayer.Top - Shots.Height;
            Shots.SizeMode = PictureBoxSizeMode.StretchImage;
            Bitmap Temp = Properties.Resources.PlayerShot;
            Temp.MakeTransparent(Temp.GetPixel(0, 0));
            Shots.Image = Temp;

            Shots.Name = "picshots" + FiredShots.ToString("");
            if (FiredShots == 254)
            {
                FiredShots = 0;
            }
            else
            {
                FiredShots += 1;
            }
            //PlayerShotSound.Play();
            Controls.Add(Shots);
            ShotCooldown = true;
            ShotCoolDownTimer.Enabled = true;
        }

        private void tmrShots_Tick(object sender, EventArgs e)
        {
             byte counter = 0;
            do
            {
                if (Controls.ContainsKey("picshots" + counter.ToString("")) == true)
                {
                    Control[] Temporary = Controls.Find("picshots" + counter.ToString(""), true);
                    Control Temps = Temporary[0];
                    if (Temps.Top <= 0)
                    {
                        Controls.Remove(Temps);
                    }
                    else
                    {
                        Temps.Top -= 5;
                    }
                }
                counter += 1;
            } while (counter != 255);
        }

        private void Movement_Tick(object sender, EventArgs e)
        {
            TestLocation();
            if (MovingLeft == true && LeftMove == false)
            {
                picPlayer.Left -= 5;
            }
            else if (MovingRight == true && RightMove == false)
            {
                picPlayer.Left += 5;
            }
            else if (MovingDown == true && DownMove == false)
            {
                picPlayer.Top += 5;
            }
            else if (MovingUp == true && UpMove == false)
            {
                picPlayer.Top -= 5;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            MovingDown = false;
            MovingLeft = false;
            MovingRight = false;
            MovingUp = false;

        }

        private void ShotCoolDownTimer_Tick(object sender, EventArgs e)
        {
            ShotCooldown = false;
            ShotCoolDownTimer.Enabled = false;
        }

        private void picMainMenu_Click(object sender, EventArgs e)
        {
            MenuSetUp();
        }

        private void MenuSetUp()
        {
            var FrmMenu = new Main_Menu();
            PauseGame();
            FrmMenu.ShowDialog();
            StartGame();
        }

        private void PauseGame()
        {
            tmrShots.Stop();
            Movement.Stop();
            tmrEnemy.Stop();
            EnemySpawn.Stop();
            ShotCoolDownTimer.Stop();
        }

        private void StartGame()
        {
            tmrShots.Start();
            Movement.Start();
            tmrEnemy.Start();
            EnemySpawn.Start();
            ShotCoolDownTimer.Start();
        }

        private void EnemiesSpawning()
        {
            PictureBox Enemey = new PictureBox();
            Enemey.Width = picPlayer.Width;
            Enemey.Height = picPlayer.Height;

            

            Enemey.Left = EnemyLocation;
            EnemyLocation += Enemey.Width + 20;
            if (Width - Enemey.Width <= EnemyLocation)
            {
                EnemyLocation = 20;
            }

            Enemey.Top = 0;

            Enemey.Image = Properties.Resources.Badguy1;
            Enemey.Name = "picEnemy" + EnemyCounter.ToString();
            if (EnemyCounter >= 254)
            {
                EnemyCounter = 0;
            }
            else
            {
                EnemyCounter += 1;
            }
            Controls.Add(Enemey);

        }

        private void tmrEnemy_Tick(object sender, EventArgs e)
        {
            byte counter = 0;
            do
            {
                if (Controls.ContainsKey("picEnemy" + counter.ToString("")) == true)
                {
                    Control[] Temporary = Controls.Find("picEnemy" + counter.ToString(""), true);
                    Control Temps = Temporary[0];
                    if (Temps.Top <= Top - pnlUi.Height)
                    {
                        Controls.Remove(Temps);
                    }
                    else
                    {
                        Temps.Top += 5;
                    }
                }
                counter += 1;
            } while (counter != 255);
            
        }

        private void EnemySpawn_Tick(object sender, EventArgs e)
        {
            EnemiesSpawning();
        }
    }
}
