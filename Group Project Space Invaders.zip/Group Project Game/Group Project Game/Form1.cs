﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Game
{
    public partial class Form1 : Form
    {
        private bool LeftMove = false;
        private bool RightMove = false;
        private bool DownMove = false;
        private bool UpMove = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Width = Screen.PrimaryScreen.Bounds.Width;
            Height = Screen.PrimaryScreen.Bounds.Height;
            Top = 0;
            Left = 0;

            Player_Setup();
            MessageBox.Show(picPlayer.Top.ToString());
            MessageBox.Show(Height.ToString());
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            TestLocation();
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
            else if (e.KeyCode == Keys.Left)
            {
                if (LeftMove == false)
                {
                    picPlayer.Left -= 25;
                }

            }
            else if (e.KeyCode == Keys.Right)
            {
                if (RightMove == false)
                {
                    picPlayer.Left += 25;
                }

            }
            else if (e.KeyCode == Keys.Up)
            {
                if (UpMove == false)
                {
                    picPlayer.Top -= 15;
                }
            }
            else if (e.KeyCode == Keys.Down)
            {
                if (DownMove == false)
                {
                    picPlayer.Top += 15;
                }
            }
            UpMove = false;
            DownMove = false;
            RightMove = false;
            LeftMove = false;
        }

        private void Player_Setup()
        {
            picPlayer.Height = Height / 24;
            picPlayer.Width = Width / 24;
            picPlayer.Left = (Width / 2) - (picPlayer.Width / 2);
            picPlayer.Top = Height - (30 + picPlayer.Height);
        }

        private void UISetup()
        {

        }

        private void TestLocation()
        {
            if (picPlayer.Left + picPlayer.Width >= Width)
            {
                RightMove = true;
            }
            else if (picPlayer.Left <= 0)
            {
                LeftMove = true;
            }
            else if (picPlayer.Top + picPlayer.Height <= 0)
            {
                DownMove = true;
            }
            else if (picPlayer.Top <= Height - 400)
            {
                UpMove = true;
            }
        }
    }
}
