﻿namespace Group_Project_Game
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picQuit = new System.Windows.Forms.PictureBox();
            this.picReturn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picQuit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picReturn)).BeginInit();
            this.SuspendLayout();
            // 
            // picQuit
            // 
            this.picQuit.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picQuit.Image = global::Group_Project_Game.Properties.Resources.ExitButton;
            this.picQuit.Location = new System.Drawing.Point(58, 120);
            this.picQuit.Name = "picQuit";
            this.picQuit.Size = new System.Drawing.Size(100, 50);
            this.picQuit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picQuit.TabIndex = 1;
            this.picQuit.TabStop = false;
            this.picQuit.Click += new System.EventHandler(this.picQuit_Click);
            // 
            // picReturn
            // 
            this.picReturn.BackColor = System.Drawing.SystemColors.ControlDark;
            this.picReturn.Image = global::Group_Project_Game.Properties.Resources.ReturnPicture;
            this.picReturn.Location = new System.Drawing.Point(58, 27);
            this.picReturn.Name = "picReturn";
            this.picReturn.Size = new System.Drawing.Size(100, 50);
            this.picReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picReturn.TabIndex = 0;
            this.picReturn.TabStop = false;
            this.picReturn.Click += new System.EventHandler(this.picReturn_Click);
            // 
            // Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(229, 226);
            this.Controls.Add(this.picQuit);
            this.Controls.Add(this.picReturn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main_Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Main_Menu_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Main_Menu_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picQuit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picReturn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picReturn;
        private System.Windows.Forms.PictureBox picQuit;
    }
}