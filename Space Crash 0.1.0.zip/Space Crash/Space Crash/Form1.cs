﻿using System;
using System.Windows.Forms;
using System.Threading;

namespace Space_Crash
{
    public partial class Form1 : Form
    {
        public Player[] PlayerArray = new Player[0];
        public Bulet[] Shots = new Bulet[255];

        public Enemy[] Enemies = new Enemy[255];
        public int CurrentEnemy = 0;
        public int EnemyMoveCounter = 0;
        public int MovementCounter = 0;
        public int EnemyLineMove = 0;
        public int EnemyClock = 0;

        public int CurrentShot = 0; 
        public int PlayerID;
        public bool Special1 = false;
        public bool Special2 = false;

        public Random Rand = new Random();
        public string Enemy = "";

        public bool CheatSpawn = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SpawnPlayers(1);
            PlayerID = 0;
            FitScreen();
        }

        public void FitScreen()
        {
            Width = UserInputs.SelectedScreen.Bounds.Width;
            Height = UserInputs.SelectedScreen.Bounds.Height;
            Left = 0;
            Top = 0;

            pnlUI.Height = Height / 8;
            pnlUI.Top = Height - pnlUI.Height;
            pnlUI.Width = Width;
            pnlUI.Left = 0;

            label1.Text = PlayerArray[PlayerID].Score.ToString();
            label2.Text = "Score";

            label3.Text = PlayerArray[PlayerID].Kills.ToString();
            label4.Text = "Kills";

            label1.Width = 80;
            label2.Width = label1.Width;
            label3.Width = label1.Width;
            label4.Width = label1.Width;

            label2.Top = pnlUI.Height / 8;
            label1.Top = label2.Top + label1.Height;

            label1.Left = label2.Left;

            label4.Top = label2.Top;
            label3.Top = label1.Top;

            label4.Left = label2.Left + label2.Width + 2;
            label3.Left = label4.Left;
        }

        private void UpdateScreen()
        {
            // this updates the score and how many kills a player has
            label3.Text = PlayerArray[PlayerID].Kills.ToString();
            label1.Text = PlayerArray[PlayerID].Score.ToString();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = true;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = true;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = true;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = true;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = true;
            }

            if (UserInputs.KeyMenu == e.KeyCode)
            {
                Thread frm = new Thread(new ThreadStart(Program.StartMenuThread));
                frm.Start();
                Close();
            }

            if (UserInputs.PreventSpawn == e.KeyCode && UserInputs.DevMode == true)
            {
                switch (CheatSpawn)
                {
                    case true:
                        CheatSpawn = false;
                        break;
                    case false:
                        CheatSpawn = true;
                        break;
                }
            }
            if (UserInputs.SpawnEnemyLine == e.KeyCode && UserInputs.DevMode == true)
            {
                SpawnEnemy(18);
            }
            if (UserInputs.SpawnEnemyLight == e.KeyCode && Special1 != true && UserInputs.DevMode == true)
            {
                SpawnEnemies();
                Special1 = true;
            }
            if (UserInputs.SpawnEnemyCracked == e.KeyCode && Special2 != true && UserInputs.DevMode == true)
            {
                SpawnEnemies2();
                Special2 = true;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = false;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = false;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = false;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = false;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = false;
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (UserInputs.MoveDown == true)
            {
                PlayerArray[PlayerID].Body.Top += 3;
            }
            if (UserInputs.MoveLeft == true)
            {
                PlayerArray[PlayerID].Body.Left -= 3;
            }
            if (UserInputs.MoveRight == true)
            {
                PlayerArray[PlayerID].Body.Left += 3;
            }
            if (UserInputs.MoveUp == true)
            {
                PlayerArray[PlayerID].Body.Top -= 3;
            }
            if (UserInputs.FireShot == true && PlayerArray[PlayerID].ShotCoolDown >= 10)
            {
                if (CurrentShot == 254)
                {
                    CurrentShot = 0;
                }
                CurrentShot += 1;
                Shots[CurrentShot] = new Bulet();
                Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                Controls.Add(Shots[CurrentShot].Shot);
                Shots[CurrentShot].PlayerID = PlayerID;
                PlayerArray[PlayerID].ShotCoolDown = 0;
            }
            else
            {
                PlayerArray[PlayerID].ShotCoolDown += 1;
            }

            if (EnemyClock <= 0 && CheatSpawn == false)
            {
                int Temp = Rand.Next(20);
                switch (Temp)
                {
                    case 1:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 2:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 3:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 4:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 5:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    case 6:
                        if (Special1 == false)
                        {
                            SpawnEnemies();
                            EnemyClock = 10;
                            Special1 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 7:
                        if (Special2 == false)
                        {
                            SpawnEnemies2();
                            EnemyClock = 10;
                            Special2 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 8:
                        if (Special2 == false)
                        {
                            SpawnEnemies2();
                            EnemyClock = 10;
                            Special2 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;
                    case 9:
                        if (Special2 == false)
                        {
                            SpawnEnemies2();
                            EnemyClock = 10;
                            Special2 = true;
                        }
                        else
                        {
                            SpawnEnemy(18);
                            EnemyClock = 300;
                        }
                        break;

                    default:
                        SpawnEnemy(18);
                        EnemyClock = 300;
                        break;
                }
                label5.Text = Temp.ToString();
            }
            else
            {
                EnemyClock -= 1;
            }

            int counter = 0;
            do
            {

                if (Shots[counter] != null)
                {
                    switch (Shots[counter].Shotter) 
                    {
                        case "E":
                            Shots[counter].Shot.Top += 5;
                            if (Shots[counter].Shot.Top >= Height)
                            {
                                Controls.Remove(Shots[counter].Shot);
                                Shots[counter] = null;
                            }
                            else if (PlayerArray[PlayerID].ColisionTester.FindCollison(PlayerArray[PlayerID].Body, Shots[counter].Shot))
                            {
                                PlayerArray[PlayerID].HitPoints -= 1;
                                if (PlayerArray[PlayerID].HitPoints == 0)
                                {
                                    Controls.Remove(Shots[counter].Shot);
                                    Shots[counter] = null;

                                    Controls.Remove(PlayerArray[PlayerID].Body);
                                    PlayerArray[PlayerID] = null;
                                }
                            }
                            break;
                        case "P":
                            Shots[counter].Shot.Top -= 5;
                            if (Shots[counter].Shot.Top <= 0)
                            {
                                Controls.Remove(Shots[counter].Shot);
                                Shots[counter] = null;
                            }
                            int tempCounter = 0;
                            while (tempCounter <= 254)
                            {
                                if (Enemies[tempCounter] != null)
                                {
                                    if (Shots[counter] != null)
                                    {
                                        if (Enemies[tempCounter].CollisionTest.FindCollison(Enemies[tempCounter].Body, Shots[counter].Shot))
                                        {
                                            switch (Enemies[tempCounter].EnemyType)
                                            {
                                                case "N":
                                                    PlayerArray[Shots[counter].PlayerID].Score += 10;
                                                    break;
                                                case "C":
                                                    PlayerArray[Shots[counter].PlayerID].Score += 50;
                                                    Special1 = false;
                                                    break;
                                                case "K":
                                                    PlayerArray[Shots[counter].PlayerID].Score += 100;
                                                    Special2 = false;
                                                    break;
                                                default:
                                                    PlayerArray[Shots[counter].PlayerID].Score += 10;
                                                    break;
                                            }
                                            PlayerArray[Shots[counter].PlayerID].Kills += 1;
                                            Controls.Remove(Enemies[tempCounter].Body);
                                            Controls.Remove(Shots[counter].Shot);
                                            Shots[counter] = null;
                                            Enemies[tempCounter] = null;
                                        }
                                        else
                                        {

                                        }
                                    }
                                }
                                tempCounter += 1;
                            }

                            break;
                        default:
                            break;
                    }
                }
                counter += 1;
            } while (counter < 255);
            counter = 0;
                do
                {

                    if (Enemies[counter] != null)
                    {
                        switch (Enemies[counter].EnemyType)
                        {
                            case "C":
                                if (MovementCounter == 0)
                                {
                                    switch (Enemies[counter].Movement)
                                    {
                                        case true:
                                            if (Enemies[counter].Body.Left <= Width - Enemies[counter].Body.Width)
                                            {
                                                Enemies[counter].Body.Left += 8;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = false;
                                                Enemies[counter].Body.Top += 15;
                                            }
                                            break;

                                        case false:
                                            if (Enemies[counter].Body.Left >= 0)
                                            {
                                                Enemies[counter].Body.Left -= 8;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = true;
                                                Enemies[counter].Body.Top += 15;
                                            }
                                            break;
                                    default:
                                        Enemies[counter].Movement = true;
                                        Enemies[counter].Body.Top += 15;
                                        break;
                                    }
                                    if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                    {
                                        Controls.Remove(Enemies[counter].Body);
                                        Enemies[counter] = null;
                                    }
                                }
                                else
                                {
                                    MovementCounter -= 1;
                                }
                                break;

                            case "K":
                                if (MovementCounter == 0)
                                {
                                    switch (Enemies[counter].Movement)
                                    {
                                        case true:
                                            if (Enemies[counter].Body.Left <= Width - Enemies[counter].Body.Width)
                                            {
                                                Enemies[counter].Body.Left += 9;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = false;
                                                Enemies[counter].Body.Top += 30;
                                            }
                                            break;

                                        case false:
                                            if (Enemies[counter].Body.Left >= 0)
                                            {
                                                Enemies[counter].Body.Left -= 9;
                                            }
                                            else
                                            {
                                                Enemies[counter].Movement = true;
                                                Enemies[counter].Body.Top += 30;
                                            }
                                            break;

                                    default:
                                        Enemies[counter].Movement = true;
                                        Enemies[counter].Body.Top += 15;
                                        break;
                                }
                                    if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                    {
                                        Controls.Remove(Enemies[counter].Body);
                                        Enemies[counter] = null;
                                    }
                                }
                                break;

                            default:
                                if (EnemyLineMove == 8)
                                {
                                    Enemies[counter].Body.Top += 5;
                                    if (Enemies[counter].Body.Top == (Height - pnlUI.Height) - ((Height / 12) / 2))
                                    {
                                        Controls.Remove(Enemies[counter].Body);
                                        Enemies[counter] = null;
                                    }
                                }
                                break;
                        }
                    }
                    counter += 1;
                } while (counter < 255);


            if (EnemyLineMove == 8)
            {
                EnemyLineMove = 0;
            }
            else
            {
                EnemyLineMove += 1;
            }

            if (MovementCounter == 0)
            {
                MovementCounter = 2;
            }
            else
            {
                MovementCounter -= 1;
            }




            UpdateScreen();

        }

        public void SpawnPlayers(int I)
        {
            
            int counter = 0;
            Array.Resize<Player>(ref PlayerArray, I + 1);
            do
            {

                PlayerArray[counter] = new Player();
                PlayerArray[counter].CreatePlayer(Form.ActiveForm, "bob");
                Controls.Add(PlayerArray[PlayerID].Body);
                counter += 1;

            } while (counter == I);
            
        }

        //base Line Enemy
        private void SpawnEnemy(int I)
        {
            int Counter = 0;
            while(Counter <= I)
            {
                Enemies[CurrentEnemy] = new Enemy();
                Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "N");
                Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20) * Counter) - 24;
                Controls.Add(Enemies[CurrentEnemy].Body);
                Counter += 1;
                CurrentEnemy += 1;
                if (CurrentEnemy == 254)
                {
                    CurrentEnemy = 0;
                }
            }
        }

        //Light Enemy
        private void SpawnEnemies()
        {
            Enemies[CurrentEnemy] = new Enemy();
            Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "C");
            Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20)) - 24;
            Controls.Add(Enemies[CurrentEnemy].Body);
            CurrentEnemy += 1;
            if (CurrentEnemy == 254)
            {
                CurrentEnemy = 0;
            }
        }

        //Crack Enemy
        private void SpawnEnemies2()
        {
            Enemies[CurrentEnemy] = new Enemy();
            Enemies[CurrentEnemy].CreateEnemy(ActiveForm, "K");
            Enemies[CurrentEnemy].Body.Width /= 2;
            Enemies[CurrentEnemy].Body.Left = (Width - (Enemies[CurrentEnemy].Body.Width + 10)) - ((Enemies[CurrentEnemy].Body.Width + 20)) - 24;
            Controls.Add(Enemies[CurrentEnemy].Body);
            CurrentEnemy += 1;
            if (CurrentEnemy == 254)
            {
                CurrentEnemy = 0;
            }
        }
    }
}
