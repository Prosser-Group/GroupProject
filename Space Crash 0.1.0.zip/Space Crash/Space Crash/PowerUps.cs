﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    class PowerUps
    {
        public HitBox Colider;
        public string Name;
        public PictureBox Body;

        public void SetSpecial(string N, Point l, Form PlayingFeild, PictureBox P)
        {
            Body = new PictureBox
            {
                Location = l,
                Height = 1,
                Width = 1
            };
            Name = N;
            Colider = new HitBox();
        }
    }
}
