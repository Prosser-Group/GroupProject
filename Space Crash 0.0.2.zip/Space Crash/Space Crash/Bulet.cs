﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Space_Crash
{
    public class Bulet
    {
        public PictureBox Shot;
        public string Shotter = "";
        public int PlayerID = 9999;
        public HitBox Colider;

        public void CreateShot(Form PlayingFeild, string N, PictureBox P)
        {
            Shotter = N;
            Colider = new HitBox();
            SetUpShot(PlayingFeild.Height, PlayingFeild.Width,P);
        }

        private void SetUpShot(int H, int W, PictureBox P)
        {
            Shot = new PictureBox
            {
                Width = W / 82,
                Height = H / 42,
                Top = P.Top - H / 42,
                Left = P.Left + ((P.Width / 2) -((W / 120) / 2)),
                BackColor = SystemColors.ButtonShadow
            };

        }
    }


}
