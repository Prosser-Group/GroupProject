﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class Form1 : Form
    {
        public Player[] PlayerArray = new Player[0];
        public Bulet[] Shots = new Bulet[255];
        public int CurrentShot = 0; 
        public int PlayerID;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FitScreen();
            SpawnPlayers(1);
            PlayerID = 0;
        }

        public void FitScreen()
        {
            Width = UserInputs.SelectedScreen.Bounds.Width;
            Height = UserInputs.SelectedScreen.Bounds.Height;
            Left = 0;
            Top = 0;

            pnlUI.Height = Height / 8;
            pnlUI.Top = Height - pnlUI.Height;
            pnlUI.Width = Width;
            pnlUI.Left = 0;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = true;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = true;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = true;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = true;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = true;
            }

            if (UserInputs.KeyMenu == e.KeyCode)
            {
                Application.Exit();
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = false;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = false;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = false;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = false;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = false;
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (UserInputs.MoveDown == true)
            {
                PlayerArray[PlayerID].Body.Top += 3;
            }
            if (UserInputs.MoveLeft == true)
            {
                PlayerArray[PlayerID].Body.Left -= 3;
            }
            if (UserInputs.MoveRight == true)
            {
                PlayerArray[PlayerID].Body.Left += 3;
            }
            if (UserInputs.MoveUp == true)
            {
                PlayerArray[PlayerID].Body.Top -= 3;
            }
            if (UserInputs.FireShot == true && PlayerArray[PlayerID].ShotCoolDown >= 20)
            {
                if (CurrentShot == 254)
                {
                    CurrentShot = 0;
                }
                CurrentShot += 1;
                Shots[CurrentShot] = new Bulet();
                Shots[CurrentShot].CreateShot(Form.ActiveForm, "P", PlayerArray[PlayerID].Body);
                Controls.Add(Shots[CurrentShot].Shot);
                Shots[CurrentShot].PlayerID = PlayerID;
                PlayerArray[PlayerID].ShotCoolDown = 0;
            }
            else
            {
                PlayerArray[PlayerID].ShotCoolDown += 1;
            }
            int counter = 0;
            do
            {

                if (Shots[counter] != null)
                {
                    switch (Shots[counter].Shotter) 
                    {
                        case "E":
                            Shots[counter].Shot.Top += 4;
                            if (Shots[counter].Shot.Top >= Height)
                            {
                                Controls.Remove(Shots[counter].Shot);
                                Shots[counter] = null;
                            }
                            break;
                        case "P":
                            Shots[counter].Shot.Top -= 4;
                            if (Shots[counter].Shot.Top <= 0)
                            {
                                Controls.Remove(Shots[counter].Shot);
                                Shots[counter] = null;
                            }
                            break;
                        default:
                            break;
                    }
                }
                counter += 1;
            } while (counter < 255);
        }

        public void SpawnPlayers(int I)
        {
            int counter = 0;
            Array.Resize<Player>(ref PlayerArray, I + 1);
            do
            {

                PlayerArray[counter] = new Player();
                PlayerArray[counter].CreatePlayer(Form.ActiveForm, "bob");
                Controls.Add(PlayerArray[PlayerID].Body);
                counter += 1;

            } while (counter == I);
            
        }
    }
}
