﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using WMPLib;

namespace Space_Crash
{
    static class Program
    {
        public static void StateGameThread()
        {
            var frm = new Form1();
            frm.ShowDialog();
        }

        public static void StartMenuThread()
        {
            var frm = new Menu();
            frm.ShowDialog();
        }

        public static void PlaybackGroundSound()
        {
            WindowsMediaPlayer BackGround = new WindowsMediaPlayer();
            BackGround.URL = Properties.Resources;
            BackGround.controls.play();
        }

        public static void PlayFireShotSound()
        {
            WindowsMediaPlayer FireShot = new WindowsMediaPlayer();
            FireShot.URL = Properties.Resources;
            FireShot.controls.play();
        }

        public static void PlayEnemyShotSound()
        {
            WindowsMediaPlayer EnemyShot = new WindowsMediaPlayer();
            EnemyShot.URL = Properties.Resources;
            EnemyShot.controls.play();
        }

        public static void PlayEnemyDestructionSound()
        {
            WindowsMediaPlayer Destruction = new WindowsMediaPlayer();
            Destruction.URL = Properties.Resources;
            Destruction.controls.play();
        }

        public static void PlayPlayerDestructionSound()
        {
            WindowsMediaPlayer PlayerDestruction = new WindowsMediaPlayer();
            PlayerDestruction.URL = Properties.Resources;
            PlayerDestruction.controls.play();
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [MTAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Menu());            
        }
    }
}
