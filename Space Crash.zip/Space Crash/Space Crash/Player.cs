﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
   public class Player
    {
        public PictureBox Body;
        public HitBox ColisionTester;
        public double Score;
        public int Kills;
        public int HitPoints;
        public string Name;

        public void CreatePlayer(Form PlayingFeild, string N)
        {
            Name = N;
            SetUpBody();
            Score = 0;
            Kills = 0;
            HitPoints = 3;
            ColisionTester = new HitBox();
            PlayingFeild.Controls.Add(Body);
        }

        private void SetUpBody()
        {
            Body = new PictureBox();
        }

        public dynamic FireShot(Form PlayingFeild)
        {
            PictureBox shot = new PictureBox();
            spawnShot(shot);
            return shot;
        }

        private void spawnShot(PictureBox S)
        {

        }

    }
}
