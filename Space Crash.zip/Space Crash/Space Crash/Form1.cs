﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    public partial class Form1 : Form
    {
        public Player[] PlayerArray = new Player[0];
        public Form1()
        {
            InitializeComponent();            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FitScreen();
        }

        public void FitScreen()
        {
            Width = UserInputs.SelectedScreen.Bounds.Width;
            Height = UserInputs.SelectedScreen.Bounds.Height;
            Left = 0;
            Top = 0;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = true;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = true;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = true;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = true;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = true;
            }

            if (UserInputs.KeyMenu == e.KeyCode)
            {
                Application.Exit();
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (UserInputs.KeyUp == e.KeyCode)
            {
                UserInputs.MoveUp = false;
            }
            if (UserInputs.KeyRight == e.KeyCode)
            {
                UserInputs.MoveRight = false;
            }
            if (UserInputs.KeyDown == e.KeyCode)
            {
                UserInputs.MoveDown = false;
            }
            if (UserInputs.KeyLeft == e.KeyCode)
            {
                UserInputs.MoveLeft = false;
            }

            if (UserInputs.KeyShot == e.KeyCode)
            {
                UserInputs.FireShot = false;
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {

        }

        public void SpawnPlayers(int I)
        {
            int counter = 0;
            Array.Resize<Player>(ref PlayerArray, I);
            do
            {
                PlayerArray[counter] = new Player();
                counter += 1;
            } while (counter == I);
        }
    }
}
