﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Crash
{
    public static class UserInputs
    {
        public static Keys KeyUp = Keys.Up;
        public static bool MoveUp = false;
        public static Keys KeyRight = Keys.Right;
        public static bool MoveRight = false;
        public static Keys KeyDown = Keys.Down;
        public static bool MoveDown = false;
        public static Keys KeyLeft = Keys.Left;
        public static bool MoveLeft = false;

        public static Keys KeyShot = Keys.Space;
        public static bool FireShot = false;
        public static Keys KeyMenu = Keys.Escape;

        public static Screen SelectedScreen = Screen.PrimaryScreen;

        public static bool DevMode = false;

        public static Keys PreventSpawn = Keys.F;
        public static Keys GodMode = Keys.G;
        public static Keys ClearWorld = Keys.H;
        public static Keys SpawnEnemyLine = Keys.D1;
        public static Keys SpawnEnemyLight = Keys.D2;
        public static Keys SpawnEnemyCracked = Keys.D3;                
    }
}
