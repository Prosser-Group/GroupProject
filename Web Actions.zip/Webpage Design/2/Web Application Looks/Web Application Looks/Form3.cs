﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Web_Application_Looks
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            Left = (Screen.PrimaryScreen.Bounds.Width / 2) - (Width / 2);
            Top = (Screen.PrimaryScreen.Bounds.Height / 2) - (Height / 2);
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
