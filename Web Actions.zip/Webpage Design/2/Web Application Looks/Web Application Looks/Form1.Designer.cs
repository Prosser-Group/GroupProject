﻿namespace Web_Application_Looks
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button18 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label23 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.label34 = new System.Windows.Forms.Label();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.label33 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label29 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2068, 100);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(1791, 55);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 4;
            this.button18.Text = "Sign Out";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1981, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 45);
            this.button1.TabIndex = 3;
            this.button1.Text = "Sign Out";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1749, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 43);
            this.label1.TabIndex = 2;
            this.label1.Text = "Welcome Aaron Zirkle\r\nWould you like to sign out?\r\n";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel9.Controls.Add(this.label9);
            this.panel9.Location = new System.Drawing.Point(1543, 7);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(200, 90);
            this.panel9.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(6, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(194, 88);
            this.label9.TabIndex = 0;
            this.label9.Text = "Account Info";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel8.Controls.Add(this.label8);
            this.panel8.Location = new System.Drawing.Point(1300, 7);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(200, 90);
            this.panel8.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(3, 2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(194, 88);
            this.label8.TabIndex = 0;
            this.label8.Text = "Account Holders";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(1029, 7);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(200, 90);
            this.panel7.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(3, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(194, 88);
            this.label7.TabIndex = 0;
            this.label7.Text = "Budget";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(756, 7);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 90);
            this.panel6.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(3, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(194, 88);
            this.label6.TabIndex = 0;
            this.label6.Text = "Categories";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(504, 7);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 90);
            this.panel5.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(194, 88);
            this.label5.TabIndex = 0;
            this.label5.Text = "Transactions";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(268, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 90);
            this.panel4.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(3, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 88);
            this.label4.TabIndex = 0;
            this.label4.Text = "Banks";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(30, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 90);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(197, 88);
            this.label3.TabIndex = 0;
            this.label3.Text = "Accounts";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(0, 103);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(2068, 1075);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Wheat;
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Accounts";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(1240, 320);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 23);
            this.label12.TabIndex = 9;
            this.label12.Text = "Current Balance";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(665, 320);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 23);
            this.label11.TabIndex = 8;
            this.label11.Text = "Account Type";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(3, 320);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 23);
            this.label10.TabIndex = 7;
            this.label10.Text = "Bank Name";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1346, 305);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 42);
            this.button4.TabIndex = 5;
            this.button4.Text = "Edit";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(771, 301);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 42);
            this.button3.TabIndex = 4;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(151, 301);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 42);
            this.button2.TabIndex = 3;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Items.AddRange(new object[] {
            "First Harrison\t\t\t\t\t\tSavings   \t\t\t\t\t\t$58.32",
            resources.GetString("listBox1.Items"),
            "Chase Bank   \t\t\t\t\t\tChecking\t\t\t\t\t\t$231.00"});
            this.listBox1.Location = new System.Drawing.Point(0, 346);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(2060, 679);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(687, 64);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(499, 100);
            this.panel3.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(493, 73);
            this.label2.TabIndex = 0;
            this.label2.Text = "$289.32";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Wheat;
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.button9);
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Banks";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(1833, 319);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 23);
            this.label17.TabIndex = 16;
            this.label17.Text = "Phone Number";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(1501, 320);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 23);
            this.label16.TabIndex = 15;
            this.label16.Text = "State";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(1144, 319);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 23);
            this.label15.TabIndex = 14;
            this.label15.Text = "City";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(581, 319);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 23);
            this.label14.TabIndex = 13;
            this.label14.Text = "Address";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(8, 319);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 23);
            this.label13.TabIndex = 12;
            this.label13.Text = "Bank Name";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1683, 301);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 42);
            this.button6.TabIndex = 11;
            this.button6.Text = "Veiw";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1063, 301);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 42);
            this.button7.TabIndex = 10;
            this.button7.Text = "Edit";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(500, 297);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 42);
            this.button8.TabIndex = 9;
            this.button8.Text = "Delete";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(151, 301);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 42);
            this.button9.TabIndex = 8;
            this.button9.Text = "Add";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 25;
            this.listBox2.Items.AddRange(new object[] {
            "First Harison  \t\t\tWoadRoad 1209 Ln.\t\t\t\tNew Salsbury\t\t\tIN\t\t\t(812)-367-4394",
            resources.GetString("listBox2.Items"),
            "Chase Bank   \t\t\tWoadRoad 1209 Ln.\t\t\t\tNew Salsbury\t\t\tIN\t\t\t(812)-367-4394"});
            this.listBox2.Location = new System.Drawing.Point(0, 345);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(2060, 679);
            this.listBox2.TabIndex = 7;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Wheat;
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.listBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Transactions";
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(1228, 324);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 23);
            this.label24.TabIndex = 28;
            this.label24.Text = "Ammount";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(1564, 324);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 23);
            this.label22.TabIndex = 26;
            this.label22.Text = "Category";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(829, 324);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(100, 23);
            this.label21.TabIndex = 25;
            this.label21.Text = "Account";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(383, 320);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 23);
            this.label20.TabIndex = 24;
            this.label20.Text = "Date";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(97, 320);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 23);
            this.label19.TabIndex = 23;
            this.label19.Text = "Action";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(3, 324);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 23);
            this.label18.TabIndex = 22;
            this.label18.Text = "ID";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(1399, 305);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 42);
            this.button10.TabIndex = 21;
            this.button10.Text = "Veiw";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(998, 301);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 42);
            this.button11.TabIndex = 20;
            this.button11.Text = "Edit";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(666, 301);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 42);
            this.button12.TabIndex = 19;
            this.button12.Text = "Delete";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(270, 301);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 42);
            this.button13.TabIndex = 18;
            this.button13.Text = "Add";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // listBox3
            // 
            this.listBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 25;
            this.listBox3.Items.AddRange(new object[] {
            "1\tWithdraw\t\t\t2/16/2019\t\t\t(1)Chase Bank Checking\t\t\t$98.23\t\t\tEntertainment",
            resources.GetString("listBox3.Items"),
            "2\tWithdraw\t\t\t2/18/2019\t\t\t(1)Chase bank Checking\t\t\t$39.73\t\t\tFood",
            resources.GetString("listBox3.Items1"),
            "3\tDeposit\t\t\t2/26/2019\t\t\t(1)First Harison Savings\t\t\t$200.43\t\t\tDeposit",
            resources.GetString("listBox3.Items2"),
            "4\tDeposit\t\t\t2/26/2019\t\t\t(2)First Harison Savings\t\t\t$63.28\t\t\tDeposit",
            resources.GetString("listBox3.Items3"),
            "5\tWithdraw\t\t\t3/10/2019\t\t\t(2)Chase Bank Checking\t\t\t$23.56\t\t\tGas",
            resources.GetString("listBox3.Items4")});
            this.listBox3.Location = new System.Drawing.Point(0, 349);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(2060, 679);
            this.listBox3.TabIndex = 17;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Wheat;
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.button14);
            this.tabPage4.Controls.Add(this.button15);
            this.tabPage4.Controls.Add(this.button16);
            this.tabPage4.Controls.Add(this.button17);
            this.tabPage4.Controls.Add(this.listBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Account Holders";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(1240, 323);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 23);
            this.label23.TabIndex = 17;
            this.label23.Text = "Accounts used by";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(665, 323);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 23);
            this.label25.TabIndex = 16;
            this.label25.Text = "Account Type";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(3, 323);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(100, 23);
            this.label26.TabIndex = 15;
            this.label26.Text = "Account Name";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(1804, 308);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 42);
            this.button14.TabIndex = 14;
            this.button14.Text = "Veiw";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(1346, 308);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 42);
            this.button15.TabIndex = 13;
            this.button15.Text = "Edit";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(771, 304);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 42);
            this.button16.TabIndex = 12;
            this.button16.Text = "Delete";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(151, 304);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 42);
            this.button17.TabIndex = 11;
            this.button17.Text = "Add";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // listBox4
            // 
            this.listBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 25;
            this.listBox4.Items.AddRange(new object[] {
            "Jimmy Salsman\t\t\t\t\t\tAdmin   \t\t\t\t\t\t2",
            resources.GetString("listBox4.Items"),
            "David Salsman   \t\t\t\t\t\tUser\t\t\t\t\t\t1"});
            this.listBox4.Location = new System.Drawing.Point(0, 349);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(2060, 679);
            this.listBox4.TabIndex = 10;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Wheat;
            this.tabPage5.Controls.Add(this.panel12);
            this.tabPage5.Controls.Add(this.panel10);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "User Info";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkGray;
            this.panel12.Controls.Add(this.button32);
            this.panel12.Controls.Add(this.button31);
            this.panel12.Controls.Add(this.button30);
            this.panel12.Controls.Add(this.button29);
            this.panel12.Controls.Add(this.button28);
            this.panel12.Controls.Add(this.listBox8);
            this.panel12.Controls.Add(this.label34);
            this.panel12.Controls.Add(this.listBox7);
            this.panel12.Controls.Add(this.label33);
            this.panel12.Location = new System.Drawing.Point(0, 104);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1944, 897);
            this.panel12.TabIndex = 3;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(916, 177);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(100, 23);
            this.button32.TabIndex = 8;
            this.button32.Text = "Remove Phone";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(916, 254);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(100, 23);
            this.button31.TabIndex = 7;
            this.button31.Text = "Remove Email";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(916, 342);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(100, 23);
            this.button30.TabIndex = 6;
            this.button30.Text = "Delete Account";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(916, 106);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(100, 23);
            this.button29.TabIndex = 5;
            this.button29.Text = "Add Phone";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(916, 44);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(100, 23);
            this.button28.TabIndex = 4;
            this.button28.Text = "Add Email";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // listBox8
            // 
            this.listBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox8.FormattingEnabled = true;
            this.listBox8.ItemHeight = 20;
            this.listBox8.Items.AddRange(new object[] {
            "(392)-874-9098",
            "(823)-902-8352",
            "(297)-873-9642",
            "(819)-829-8302"});
            this.listBox8.Location = new System.Drawing.Point(1122, 44);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(822, 784);
            this.listBox8.TabIndex = 3;
            // 
            // label34
            // 
            this.label34.Location = new System.Drawing.Point(1307, 18);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 23);
            this.label34.TabIndex = 2;
            this.label34.Text = "Phone Numbers";
            this.label34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // listBox7
            // 
            this.listBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox7.FormattingEnabled = true;
            this.listBox7.ItemHeight = 20;
            this.listBox7.Items.AddRange(new object[] {
            "Example@gmail.com",
            "Examples19203GrayTurkeys@gmail.com",
            "GoldMonkeys12300Example@Yahoo.com"});
            this.listBox7.Location = new System.Drawing.Point(0, 44);
            this.listBox7.Name = "listBox7";
            this.listBox7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox7.Size = new System.Drawing.Size(797, 784);
            this.listBox7.TabIndex = 1;
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(185, 18);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(100, 23);
            this.label33.TabIndex = 0;
            this.label33.Text = "Emails";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LightGray;
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.button27);
            this.panel10.Controls.Add(this.button26);
            this.panel10.Controls.Add(this.label32);
            this.panel10.Controls.Add(this.label31);
            this.panel10.Controls.Add(this.textBox1);
            this.panel10.Controls.Add(this.textBox2);
            this.panel10.Location = new System.Drawing.Point(809, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(323, 95);
            this.panel10.TabIndex = 2;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // panel11
            // 
            this.panel11.Location = new System.Drawing.Point(-696, 101);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1432, 100);
            this.panel11.TabIndex = 3;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(213, 9);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(107, 23);
            this.button27.TabIndex = 6;
            this.button27.Text = "Change Username";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(213, 49);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(107, 23);
            this.button26.TabIndex = 5;
            this.button26.Text = "Change Password";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(1, 51);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 20);
            this.label32.TabIndex = 4;
            this.label32.Text = "Pass Word:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.Location = new System.Drawing.Point(1, 12);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(100, 20);
            this.label31.TabIndex = 3;
            this.label31.Text = "User Name :";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(107, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(107, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Wheat;
            this.tabPage6.Controls.Add(this.pictureBox1);
            this.tabPage6.Controls.Add(this.comboBox1);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.label30);
            this.tabPage6.Controls.Add(this.button22);
            this.tabPage6.Controls.Add(this.listBox6);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Budget";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "March 2018",
            "April 2018",
            "May 2018",
            "June 2018",
            "July 2018"});
            this.comboBox1.Location = new System.Drawing.Point(796, 3);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 26;
            // 
            // label27
            // 
            this.label27.Location = new System.Drawing.Point(656, 299);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 23);
            this.label27.TabIndex = 24;
            this.label27.Text = "Max Usage";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(1231, 299);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(100, 23);
            this.label28.TabIndex = 23;
            this.label28.Text = "Current Usage";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label30
            // 
            this.label30.Location = new System.Drawing.Point(3, 306);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(100, 23);
            this.label30.TabIndex = 22;
            this.label30.Text = "Category Name";
            this.label30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(818, 284);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 42);
            this.button22.TabIndex = 21;
            this.button22.Text = "Edit";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // listBox6
            // 
            this.listBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 25;
            this.listBox6.Items.AddRange(new object[] {
            "Food\t\t\t\t\t\t\t$250   \t\t\t\t\t\t$87.90",
            resources.GetString("listBox6.Items"),
            "Rent \t  \t\t\t\t\t\t$680\t\t\t\t\t\t$680",
            resources.GetString("listBox6.Items1"),
            "Entertainment\t\t\t\t\t\t$50   \t\t\t\t\t\t$14.23",
            resources.GetString("listBox6.Items2"),
            "Utilities\t\t\t\t\t\t\t$170   \t\t\t\t\t\t$170",
            resources.GetString("listBox6.Items3"),
            "Savings\t\t\t\t\t\t\t$125   \t\t\t\t\t\t$125"});
            this.listBox6.Location = new System.Drawing.Point(0, 332);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(2060, 679);
            this.listBox6.TabIndex = 18;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Wheat;
            this.tabPage7.Controls.Add(this.label29);
            this.tabPage7.Controls.Add(this.button19);
            this.tabPage7.Controls.Add(this.button20);
            this.tabPage7.Controls.Add(this.button21);
            this.tabPage7.Controls.Add(this.listBox5);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(2060, 1049);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Categories";
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(3, 332);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(100, 23);
            this.label29.TabIndex = 23;
            this.label29.Text = "Category Name";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(1346, 317);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 42);
            this.button19.TabIndex = 21;
            this.button19.Text = "Edit";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(771, 313);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 42);
            this.button20.TabIndex = 20;
            this.button20.Text = "Delete";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(151, 313);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 42);
            this.button21.TabIndex = 19;
            this.button21.Text = "Add";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // listBox5
            // 
            this.listBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 25;
            this.listBox5.Items.AddRange(new object[] {
            "Entertainment",
            resources.GetString("listBox5.Items"),
            "Food",
            resources.GetString("listBox5.Items1"),
            "Rent",
            resources.GetString("listBox5.Items2"),
            "Savings"});
            this.listBox5.Location = new System.Drawing.Point(0, 358);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(2060, 679);
            this.listBox5.TabIndex = 18;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1804, 305);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 42);
            this.button5.TabIndex = 6;
            this.button5.Text = "Veiw";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Web_Application_Looks.Properties.Resources.download;
            this.pictureBox1.Location = new System.Drawing.Point(668, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(359, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1940, 1100);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button5;
    }
}

