﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Dice_Roller
{
    class Dice
    {
        public Boolean Selected = false;

        private Bitmap One;
        private Bitmap OneSelected;
        private Bitmap Two;
        private Bitmap TwoSelected;
        private Bitmap Three;
        private Bitmap ThreeSelected;
        private Bitmap Four;
        private Bitmap FourSelected;
        private Bitmap Five;
        private Bitmap FiveSelected;
        private Bitmap Six;
        private Bitmap SixSelected;

        private PictureBox TempPicture;
        private Byte Roll;

        public byte Num;

        public void RollDie()
        {
            if (Selected != true)
            {
                Random Rand = new Random();
                Roll = (Byte)(Rand.Next(1, 6));
                if (Roll == 1)
                {
                    TempPicture.Image = One;
                }
                else if (Roll == 2)
                {
                    TempPicture.Image = Two;
                }
                else if (Roll == 3)
                {
                    TempPicture.Image = Three;
                }
                else if (Roll == 4)
                {
                    TempPicture.Image = Four;
                }
                else if (Roll == 5)
                {
                    TempPicture.Image = Five;
                }
                else if (Roll == 6)
                {
                    TempPicture.Image = Six;
                }
                else
                {

                }
                Num = Roll;
            }
        }

        public void ImageUpdate(PictureBox Pic)
        {
            Pic.Image = TempPicture.Image;
        }

        public void SelectedDie()
        {
            Selected = true;
            if (Roll == 1)
            {
                TempPicture.Image = OneSelected;
            }
            else if (Roll == 2)
            {
                TempPicture.Image = TwoSelected;
            }
            else if (Roll == 3)
            {
                TempPicture.Image = ThreeSelected;
            }
            else if (Roll == 4)
            {
                TempPicture.Image = FourSelected;
            }
            else if (Roll == 5)
            {
                TempPicture.Image = FiveSelected;
            }
            else if (Roll == 6)
            {
                TempPicture.Image = SixSelected;
            }
            else
            {

            }
        }

        public void Reset()
        {
            Selected = false;
            Roll = 0;
            Num = 0;
        }
    }
}
