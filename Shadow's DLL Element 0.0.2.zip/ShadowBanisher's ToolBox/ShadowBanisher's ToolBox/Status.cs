﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShadowBanisher_s_ToolBox
{
    public class Status
    {
        public StatsList Player_Being;

        private double HitPoints;
        private double ManaPoints;

        private int HPMAX;
        private int MANAMAX;

        public double HitpointFinder
        {
            get
            {
                return HitPoints;
            }

            set
            {
                double temp = value + HitPoints;
                if (temp > double.Parse(HPMAX.ToString()))
                {
                    HitPoints = double.Parse(HPMAX.ToString());
                }
                else
                {
                    HitPoints = value;
                }
            }
        }

        public double ManaFinder
        {
            get
            {
                return ManaPoints;
            }

            set
            {
                double temp = value + ManaPoints;
                if (temp > double.Parse(MANAMAX.ToString()))
                {
                    ManaPoints = double.Parse(MANAMAX.ToString());
                }
                else
                {
                    ManaPoints = value;
                }
            }
        }
    }
}
