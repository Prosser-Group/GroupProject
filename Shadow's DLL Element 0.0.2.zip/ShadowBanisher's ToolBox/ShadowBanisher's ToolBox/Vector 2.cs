﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ShadowBanisher_s_ToolBox
{
    public class Vector_2 : SightPoint
    {
        public int Width = 0;
        public int Height = 0;
    }
}
