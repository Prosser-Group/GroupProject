﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test_7
{
    public partial class Form1 : Form
    {
        private PictureBox picshot = new PictureBox();
        private Boolean shot = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (shot == false)
            {
                picshot.Width = 10;
                picshot.Height = 10;
                picshot.BackColor = SystemColors.ControlDark;
                picshot.Left = picPlayer.Left + picshot.Width;
                picshot.Top = picPlayer.Top - picshot.Height;
                Controls.Add(picshot);
                shot = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            picshot.Top -= 4;
            if (picshot.Top <= 0)
            {
                Controls.Remove(picshot);
                shot = false;
            }
        }
    }
}
