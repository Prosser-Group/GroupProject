﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Compresion
{
    public partial class Form1 : Form
    {
        string[] A;
        private string Path = Properties.Resources.commonwords;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            switch (MessageBox.Show("Do you wish to exit this program?", "Closing", MessageBoxButtons.YesNo))
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCompress_Click(object sender, EventArgs e)
        {
            StreamReader S;
            try
            {
                S = File.OpenText(Path);
                A = (S.ReadToEnd()).Split(';');
                S.Close();
                if (ofdOpen.ShowDialog() == DialogResult.OK)
                {
                    S = File.OpenText(ofdOpen.FileName);
                    string R = S.ReadToEnd();
                    S.Close();
                    R = CompressFile(R);
                    
                    StreamWriter WR;
                    WR = File.CreateText(ofdOpen.FileName);
                    WR.Write(R);
                    WR.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private string CompressFile(string Q)
        {
            int count = 0;
            int L = A.GetLength(0);
            int Z = Q.Length;
            while (count < L)
            {
                int Index = 0;
                while (Index != Z && Index != -1)
                {
                    Index = Q.IndexOf(A[count], Index);
                    if (Index != -1)
                    {
                        Q = Q.Remove(Index, A[count].Length);
                        Q = Q.Insert(Index, count.ToString());
                    }
                }
                count += 1;
            }

            return Q;
        }
    }
}
