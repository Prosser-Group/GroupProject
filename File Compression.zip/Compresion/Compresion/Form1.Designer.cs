﻿namespace Compresion
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCompress = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cmbCompressType = new System.Windows.Forms.ComboBox();
            this.TIP = new System.Windows.Forms.ToolTip(this.components);
            this.ofdOpen = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // btnCompress
            // 
            this.btnCompress.Location = new System.Drawing.Point(12, 39);
            this.btnCompress.Name = "btnCompress";
            this.btnCompress.Size = new System.Drawing.Size(121, 23);
            this.btnCompress.TabIndex = 0;
            this.btnCompress.Text = "Compress";
            this.TIP.SetToolTip(this.btnCompress, "Begin Compression");
            this.btnCompress.UseVisualStyleBackColor = true;
            this.btnCompress.Click += new System.EventHandler(this.btnCompress_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(12, 68);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(121, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cmbCompressType
            // 
            this.cmbCompressType.FormattingEnabled = true;
            this.cmbCompressType.Location = new System.Drawing.Point(12, 12);
            this.cmbCompressType.Name = "cmbCompressType";
            this.cmbCompressType.Size = new System.Drawing.Size(121, 21);
            this.cmbCompressType.TabIndex = 2;
            this.TIP.SetToolTip(this.cmbCompressType, "Select way of compression (Note some are better than others)");
            // 
            // ofdOpen
            // 
            this.ofdOpen.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(146, 112);
            this.Controls.Add(this.cmbCompressType);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCompress);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCompress;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cmbCompressType;
        private System.Windows.Forms.ToolTip TIP;
        private System.Windows.Forms.OpenFileDialog ofdOpen;
    }
}

